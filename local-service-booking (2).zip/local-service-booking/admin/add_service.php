<?php
session_start();
include "../config/db.php";

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header("Location: ../login.php");
    exit;
}

$msg = "";

/* SEARCH */
$where = "";
if(isset($_GET['search']) && $_GET['search'] != ""){
    $search = mysqli_real_escape_string($conn,$_GET['search']);
    $where = "WHERE service_name LIKE '%$search%'";
}

/* TOGGLE STATUS */
if(isset($_GET['toggle'])){
    $id = intval($_GET['toggle']);
    mysqli_query($conn,"
        UPDATE services 
        SET status = IF(status='active','inactive','active')
        WHERE service_id=$id
    ");
    header("Location:add_service.php");
    exit;
}

/* DELETE SERVICE */
if(isset($_GET['delete_service'])){
    $id=intval($_GET['delete_service']);
    mysqli_query($conn,"DELETE FROM services WHERE service_id=$id");
    header("Location:add_service.php");
    exit;
}

/* ADD SERVICE */
if(isset($_POST['add_service'])){
    $name = mysqli_real_escape_string($conn,$_POST['service_name']);
    $desc = mysqli_real_escape_string($conn,$_POST['description']);

    mysqli_query($conn,"
        INSERT INTO services (service_name,description,status)
        VALUES ('$name','$desc','active')
    ");

    header("Location:add_service.php");
    exit;
}

/* UPDATE SERVICE */
if(isset($_POST['update_service'])){
    $id   = intval($_POST['service_id']);
    $name = mysqli_real_escape_string($conn,$_POST['service_name']);
    $desc = mysqli_real_escape_string($conn,$_POST['description']);

    mysqli_query($conn,"
        UPDATE services 
        SET service_name='$name',description='$desc'
        WHERE service_id=$id
    ");

    header("Location:add_service.php");
    exit;
}

/* FETCH SERVICES */
$services = mysqli_query($conn,"
    SELECT * FROM services $where ORDER BY service_id DESC
");
?>

<!DOCTYPE html>
<html>
<head>
<title>Manage Services</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<style>
body { background:#f4f6f9; }
.sidebar { min-height:100vh; background:#212529; }
.sidebar a { color:#adb5bd; padding:12px; display:block; text-decoration:none; }
.sidebar a:hover,.sidebar a.active { background:#343a40; color:#fff; }
</style>
</head>
<body>

<div class="container-fluid">
<div class="row">

<div class="col-md-2 sidebar p-0">
<h5 class="text-white text-center py-3 border-bottom">ADMIN PANEL</h5>

<a class="<?= ($currunt=='dashboard.php')? 'active':'' ?>" href="dashboard.php">📊Dashboard</a>
<a class="<?= ($currunt=='add_service.php')? 'active':''?>"href="add_service.php">➕ Manage Services</a>
<a class="<?= ($currunt=='view_users.php')? 'active':''?>"href="view_users.php">👤 Users</a>
<a class="<?= ($currunt=='view_providers.php')? 'active':''?>"href="view_providers.php">👷 Providers</a>
<a class="<?= ($currunt=='view_bookings.php')? 'active':''?>"href="view_bookings.php">📋 Bookings</a>
<a class="<?= ($currunt=='manage_support.php')? 'active':''?>"href="manage_support.php">💬 Support Requests </a>
<a href="../logout.php">🚪 Logout</a>
</div>

<div class="col-md-10 p-4">

<h3 class="mb-4">Manage Services</h3>

<!-- SEARCH -->
<form method="GET" class="mb-3">
<div class="input-group">
<input type="text" name="search" class="form-control" placeholder="Search Service">
<button class="btn btn-dark">Search</button>
</div>
</form>

<!-- ADD SERVICE -->
<div class="card mb-4">
<div class="card-body">
<form method="POST">
<input type="text" name="service_name" class="form-control mb-2" placeholder="Service Name" required>
<input type="text" name="description" class="form-control mb-2" placeholder="Description">
<button name="add_service" class="btn btn-primary">Add Service</button>
</form>
</div>
</div>

<!-- SERVICE LIST -->
<div class="card">
<div class="card-body">
<table class="table table-bordered">
<thead class="table-dark">
<tr>
<th>ID</th>
<th>Service</th>
<th>Status</th>
<th>Earning</th>
<th>Action</th>
</tr>
</thead>

<tbody>

<?php while($s=mysqli_fetch_assoc($services)) { ?>

<?php
$earning=mysqli_fetch_assoc(mysqli_query($conn,"
SELECT COUNT(*)*500 total
FROM bookings
WHERE service_id=".$s['service_id']." 
AND status='completed'
"))['total'];
?>

<tr>
<td><?= $s['service_id'] ?></td>

<td>
<form method="POST" class="d-flex">
<input type="hidden" name="service_id" value="<?= $s['service_id'] ?>">
<input type="text" name="service_name" value="<?= $s['service_name'] ?>" class="form-control me-1">
<input type="text" name="description" value="<?= $s['description'] ?>" class="form-control me-1">
<button name="update_service" class="btn btn-success btn-sm">Save</button>
</form>
</td>

<td>
<?php if($s['status']=='active'){ ?>
<span class="badge bg-success">Active</span>
<?php } else { ?>
<span class="badge bg-danger">Inactive</span>
<?php } ?>
<br>
<a href="?toggle=<?= $s['service_id'] ?>" class="btn btn-warning btn-sm mt-1">Toggle</a>
</td>

<td>₹<?= $earning ?: 0 ?></td>

<td>
<a href="?delete_service=<?= $s['service_id'] ?>" 
class="btn btn-danger btn-sm"
onclick="return confirm('Delete Service?')">
Delete
</a>
</td>

</tr>

<?php } ?>

</tbody>
</table>
</div>
</div>

</div>
</div>
</div>

</body>
</html>