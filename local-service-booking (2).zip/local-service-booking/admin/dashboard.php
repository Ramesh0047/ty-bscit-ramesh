<?php
session_start();
include "../config/db.php";

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header("Location: ../login.php");
    exit;
}

/* BASIC COUNTS */
$userCount = mysqli_fetch_assoc(mysqli_query($conn,"SELECT COUNT(*) c FROM users WHERE role='user'"))['c'];
$providerCount = mysqli_fetch_assoc(mysqli_query($conn,"SELECT COUNT(*) c FROM users WHERE role='provider'"))['c'];
$serviceCount = mysqli_fetch_assoc(mysqli_query($conn,"SELECT COUNT(*) c FROM services"))['c'];
$bookingCount = mysqli_fetch_assoc(mysqli_query($conn,"SELECT COUNT(*) c FROM bookings"))['c'];

/* STATUS COUNTS */
$requested = mysqli_fetch_assoc(mysqli_query($conn,"SELECT COUNT(*) c FROM bookings WHERE status='requested'"))['c'];
$accepted  = mysqli_fetch_assoc(mysqli_query($conn,"SELECT COUNT(*) c FROM bookings WHERE status='accepted'"))['c'];
$progress  = mysqli_fetch_assoc(mysqli_query($conn,"SELECT COUNT(*) c FROM bookings WHERE status='in_progress'"))['c'];
$completed = mysqli_fetch_assoc(mysqli_query($conn,"SELECT COUNT(*) c FROM bookings WHERE status='completed'"))['c'];
$rejected  = mysqli_fetch_assoc(mysqli_query($conn,"SELECT COUNT(*) c FROM bookings WHERE status='rejected'"))['c'];

/* MONTHLY BOOKINGS */
$monthly = mysqli_query($conn,"
 SELECT MONTH(booking_date) m, COUNT(*) c
 FROM bookings
 GROUP BY MONTH(booking_date)
");

$months = [];
$counts = [];

while($row=mysqli_fetch_assoc($monthly)){
    $months[] = "Month ".$row['m'];
    $counts[] = $row['c'];
}

/* TOP PROVIDER */
$top_provider = mysqli_fetch_assoc(mysqli_query($conn,"
 SELECT u.name, COUNT(*) total
 FROM bookings b
 JOIN users u ON b.provider_id=u.user_id
 GROUP BY b.provider_id
 ORDER BY total DESC
 LIMIT 1
"));

/* TOP SERVICE */
$top_service = mysqli_fetch_assoc(mysqli_query($conn,"
 SELECT s.service_name, COUNT(*) total
 FROM bookings b
 JOIN services s ON b.service_id=s.service_id
 GROUP BY b.service_id
 ORDER BY total DESC
 LIMIT 1
"));

/* REAL REVENUE FROM INVOICES */
$revenue = mysqli_fetch_assoc(mysqli_query($conn,"
    SELECT SUM(i.amount) total
    FROM invoices i
    JOIN bookings b ON i.booking_id = b.booking_id
"))['total'];

$revenue = $revenue ?: 0;
/* SUPPORT COUNT */
$pending_support = mysqli_fetch_assoc(mysqli_query($conn,"
    SELECT COUNT(*) c FROM support_requests WHERE status='Pending'
"))['c'];
?>
<!DOCTYPE html>
<html>
<head>
<title>Admin Dashboard</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<style>
body { background:#f4f6f9; }

.sidebar {
    min-height:100vh;
    background:#212529;
}

.sidebar a {
    color:#adb5bd;
    text-decoration:none;
    padding:12px 15px;
    display:block;
}

.sidebar a:hover, .sidebar a.active {
    background:#343a40;
    color:#fff;
}

.stat-box {
    border-radius:12px;
    color:#fff;
    padding:20px;
}
</style>
</head>

<body>

<div class="container-fluid">
<div class="row">

<!-- SIDEBAR -->
<div class="col-md-2 sidebar p-0">
<h5 class="text-white text-center py-3 border-bottom">ADMIN PANEL</h5>

<a class="<?= ($currunt=='dashboard.php')? 'active':'' ?>" href="dashboard.php">📊Dashboard</a>
<a class="<?= ($currunt=='add_service.php')? 'active':''?>"href="add_service.php">➕ Manage Services</a>
<a class="<?= ($currunt=='view_users.php')? 'active':''?>"href="view_users.php">👤 Users</a>
<a class="<?= ($currunt=='view_providers.php')? 'active':''?>"href="view_providers.php">👷 Providers</a>
<a class="<?= ($currunt=='view_bookings.php')? 'active':''?>"href="view_bookings.php">📋 Bookings</a>
<a class="<?= ($currunt=='manage_support.php')? 'active':''?>"href="manage_support.php">💬 Support Requests </a>
<a href="../logout.php">🚪 Logout</a>
</div>

<!-- MAIN CONTENT -->
<div class="col-md-10 p-4">

<h3 class="mb-4">📊 Admin Main Dashboard</h3>

<!-- TOP STATS -->
<div class="row g-4 mb-4">

<div class="col-md-3">
<div class="stat-box bg-primary shadow">
<h6>Total Users</h6>
<h2><?= $userCount ?></h2>
</div>
</div>

<div class="col-md-3">
<div class="stat-box bg-success shadow">
<h6>Providers</h6>
<h2><?= $providerCount ?></h2>
</div>
</div>

<div class="col-md-3">
<div class="stat-box bg-warning shadow">
<h6>Services</h6>
<h2><?= $serviceCount ?></h2>
</div>
</div>

<div class="col-md-3">
<div class="stat-box bg-danger shadow">
<h6>Total Bookings</h6>
<h2><?= $bookingCount ?></h2>
</div>
</div>

</div>

<!-- ANALYTICS CARDS -->
<div class="row g-4 mb-4">

<div class="col-md-4">
<div class="card shadow p-3">
<h6>🏆 Top Provider</h6>
<p><?= $top_provider['name'] ?? 'N/A' ?></p>
<small><?= $top_provider['total'] ?? 0 ?> Bookings</small>
</div>
</div>

<div class="col-md-4">
<div class="card shadow p-3">
<h6>🔥 Most Booked Service</h6>
<p><?= $top_service['service_name'] ?? 'N/A' ?></p>
<small><?= $top_service['total'] ?? 0 ?> Bookings</small>
</div>
</div>

<div class="col-md-4">
<div class="card shadow p-3">
<h6>💰 Revenue</h6>
<h4>₹<?= $revenue ?></h4>
</div>
</div>
<div class="col-md-4">
<div class="card shadow p-3">
<h6>💬 Pending Support</h6>
<h4><?= $pending_support ?></h4>
</div>
</div>

</div>

<!-- CHARTS -->
<div class="row">

<div class="col-md-6">
<div class="card shadow p-4">
<h5>Booking Status</h5>
<canvas id="statusChart"></canvas>
</div>
</div>

<div class="col-md-6">
<div class="card shadow p-4">
<h5>Monthly Bookings</h5>
<canvas id="monthlyChart"></canvas>
</div>
</div>

</div>

</div>
</div>
</div>

<script>
new Chart(document.getElementById('statusChart'), {
type: 'doughnut',
data: {
labels: ['Requested','Accepted','In Progress','Completed','Rejected'],
datasets: [{
data: [<?= $requested ?>,<?= $accepted ?>,<?= $progress ?>,<?= $completed ?>,<?= $rejected ?>],
backgroundColor: ['#0d6efd','#198754','#ffc107','#0dcaf0','#dc3545']
}]
}
});

new Chart(document.getElementById('monthlyChart'), {
type: 'bar',
data: {
labels: <?= json_encode($months) ?>,
datasets: [{
label: 'Monthly Bookings',
data: <?= json_encode($counts) ?>
}]
}
});
</script>

</body>
</html>