<?php
session_start();
include "../config/db.php";

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header("Location: ../login.php");
    exit;
}

if (!isset($_GET['id'])) {
    header("Location: view_users.php");
    exit;
}

$id = intval($_GET['id']);

/* Fetch user */
$result = mysqli_query($conn, "SELECT * FROM users WHERE user_id=$id");
$user = mysqli_fetch_assoc($result);

if (!$user) {
    header("Location: view_users.php");
    exit;
}

/* Admin cannot edit admin account */
if ($user['role'] == 'admin') {
    header("Location: view_users.php");
    exit;
}

/* UPDATE */
if (isset($_POST['update'])) {

    $name  = mysqli_real_escape_string($conn, $_POST['name']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $area  = mysqli_real_escape_string($conn, $_POST['area']);
    $role  = mysqli_real_escape_string($conn, $_POST['role']);

    mysqli_query($conn, "
        UPDATE users 
        SET name='$name',
            email='$email',
            area='$area',
            role='$role'
        WHERE user_id=$id
    ");

    header("Location: view_users.php");
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Edit User</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">

<div class="container mt-5">
<div class="card shadow">
<div class="card-body">

<h4>Edit User / Provider</h4>

<form method="POST">

<div class="mb-3">
<label>Name</label>
<input type="text" name="name"
       value="<?= htmlspecialchars($user['name']) ?>"
       class="form-control" required>
</div>

<div class="mb-3">
<label>Email</label>
<input type="email" name="email"
       value="<?= htmlspecialchars($user['email']) ?>"
       class="form-control" required>
</div>

<div class="mb-3">
<label>Area</label>
<input type="text" name="area"
       value="<?= htmlspecialchars($user['area']) ?>"
       class="form-control">
</div>

<div class="mb-3">
<label>Role</label>
<select name="role" class="form-select">
    <option value="user" <?= $user['role']=='user'?'selected':'' ?>>User</option>
    <option value="provider" <?= $user['role']=='provider'?'selected':'' ?>>Provider</option>
</select>
</div>

<button type="submit" name="update" class="btn btn-success">
Update
</button>

<a href="view_users.php" class="btn btn-secondary">
Cancel
</a>

</form>

</div>
</div>
</div>

</body>
</html>