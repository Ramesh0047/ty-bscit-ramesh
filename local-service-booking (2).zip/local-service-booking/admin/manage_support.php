<?php
session_start();
include "../config/db.php";

if (!isset($_SESSION['user_id']) || $_SESSION['role']!='admin'){
header("Location: ../login.php");
exit;
}

/* UPDATE SUPPORT */

if(isset($_POST['update'])){

$id=$_POST['request_id'];

$reply=mysqli_real_escape_string($conn,$_POST['admin_reply']);

$status=mysqli_real_escape_string($conn,$_POST['status']);

mysqli_query($conn,"
UPDATE support_requests
SET admin_reply='$reply',
status='$status'
WHERE request_id='$id'
");

header("Location: manage_support.php");
exit;

}

/* FETCH REQUEST */

$support=mysqli_query($conn,"
SELECT s.*,u.name
FROM support_requests s
JOIN users u ON s.user_id=u.user_id
ORDER BY request_id DESC
");

?>

<!DOCTYPE html>
<html>
<head>

<title>Manage Support</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<style>
body { background:#f4f6f9; }

.sidebar {
    min-height:100vh;
    background:#212529;
}

.sidebar a {
    color:#adb5bd;
    text-decoration:none;
    padding:12px 15px;
    display:block;
}

.sidebar a:hover, .sidebar a.active {
    background:#343a40;
    color:#fff;
}

.stat-box {
    border-radius:12px;
    color:#fff;
    padding:20px;
}
</style>

</head>

<body>
<div class="container-fluid">
<div class="row">    

<div class="col-md-2 sidebar p-0">
<h5 class="text-white text-center py-3 border-bottom">ADMIN PANEL</h5>

<a class="<?= ($currunt=='dashboard.php')? 'active':'' ?>" href="dashboard.php">📊Dashboard</a>
<a class="<?= ($currunt=='add_service.php')? 'active':''?>"href="add_service.php">➕ Manage Services</a>
<a class="<?= ($currunt=='view_users.php')? 'active':''?>"href="view_users.php">👤 Users</a>
<a class="<?= ($currunt=='view_providers.php')? 'active':''?>"href="view_providers.php">👷 Providers</a>
<a class="<?= ($currunt=='view_bookings.php')? 'active':''?>"href="view_bookings.php">📋 Bookings</a>
<a class="<?= ($currunt=='manage_support.php')? 'active':''?>"href="manage_support.php">💬 Support Requests </a>
<a href="../logout.php">🚪 Logout</a>
</div>

<div class="col-md-10 p-4">

<h3>Support Requests Management</h3>

<table class="table table-bordered mt-3">

<tr class="table-dark">
<th>User</th>
<th>Subject</th>
<th>Description</th>
<th>Status</th>
<th>Admin Action</th>
</tr>

<?php while($s=mysqli_fetch_assoc($support)){ 

$statusColor="bg-warning";

if($s['status']=="Resolved") $statusColor="bg-success";
if($s['status']=="In Progress") $statusColor="bg-primary";

?>

<tr>

<td><?= htmlspecialchars($s['name']) ?></td>

<td><?= htmlspecialchars($s['subject']) ?></td>

<td><?= htmlspecialchars($s['description']) ?></td>

<td>
<span class="badge <?= $statusColor ?>">
<?= $s['status'] ?>
</span>
</td>

<td>

<form method="POST">

<input type="hidden" name="request_id" value="<?= $s['request_id'] ?>">

<textarea name="admin_reply" class="form-control mb-2" rows="2"><?= htmlspecialchars($s['admin_reply']) ?></textarea>

<select name="status" class="form-control mb-2">

<option value="Pending" <?= $s['status']=='Pending'?'selected':'' ?>>Pending</option>

<option value="In Progress" <?= $s['status']=='In Progress'?'selected':'' ?>>In Progress</option>

<option value="Resolved" <?= $s['status']=='Resolved'?'selected':'' ?>>Resolved</option>

</select>

<button type="submit" name="update" class="btn btn-success btn-sm">
Update
</button>

</form>

</td>

</tr>

<?php } ?>

</table>

</div>

</body>
</html>