<?php
include "../config/db.php";

$id = $_GET['id'];

mysqli_query($conn,
"UPDATE users SET status='rejected' WHERE user_id='$id'");

header("Location: view_providers.php");
?>