<div class="sidebar">

<div class="title">ADMIN PANEL</div>

<a href="dashboard.php"><i class="fa fa-chart-line"></i> Dashboard</a>
<a href="add_service.php"><i class="fa fa-plus"></i> Services</a>
<a href="view_users.php"><i class="fa fa-users"></i> Users</a>
<a href="view_providers.php">
<i class="fa fa-user-cog"></i> Providers 
<span class="badge bg-danger"><?= $pending_providers ?></span>
</a>
<a href="view_bookings.php"><i class="fa fa-list"></i> Bookings</a>
<a href="manage_support.php"><i class="fa fa-headset"></i> Support</a>
<a href="../logout.php"><i class="fa fa-sign-out-alt"></i> Logout</a>

</div>