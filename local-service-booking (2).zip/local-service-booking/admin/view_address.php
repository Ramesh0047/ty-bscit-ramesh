<?php
session_start();
include "../config/db.php";

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header("Location: ../login.php");
    exit;
}

$user_id = intval($_GET['id']);

$data = mysqli_query($conn, "
    SELECT u.name, u.role, ua.phone, ua.address
    FROM users u
    LEFT JOIN user_address ua ON u.user_id = ua.user_id
    WHERE u.user_id = $user_id
");

$row = mysqli_fetch_assoc($data);
?>

<!DOCTYPE html>
<html>
<head>
<title>User Address</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">

<div class="container mt-5">
<div class="card shadow">
<div class="card-body">

<h4><?= htmlspecialchars($row['name']) ?> - Address Details</h4>
<hr>

<p><strong>Role:</strong> <?= ucfirst($row['role']) ?></p>
<p><strong>Phone:</strong> <?= htmlspecialchars($row['phone']) ?></p>
<p><strong>Address:</strong> <?= htmlspecialchars($row['address']) ?></p>

<a href="view_users.php" class="btn btn-secondary">Back</a>

</div>
</div>
</div>

</body>
</html>