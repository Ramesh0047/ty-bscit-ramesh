<?php
session_start();
include "../config/db.php";

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header("Location: ../login.php");
    exit;
}

$providers = mysqli_query($conn, "
    SELECT 
        u.user_id,
        u.name,
        u.email,
        u.area,
        u.status,
        s.service_name,
        sp.availability
    FROM users u
    LEFT JOIN service_providers sp ON u.user_id = sp.user_id
    LEFT JOIN services s ON sp.service_id = s.service_id
    WHERE u.role = 'provider'
    ORDER BY u.user_id DESC
");
?>

<!DOCTYPE html>
<html>
<head>
<title>View Providers</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

<style>
body { background:#f4f6f9; }
.sidebar {
    min-height:100vh;
    background:#212529;
}
.sidebar a {
    color:#adb5bd;
    display:block;
    padding:12px 15px;
    text-decoration:none;
}
.sidebar a:hover, .sidebar a.active {
    background:#343a40;
    color:#fff;
}
</style>
</head>

<body>

<div class="container-fluid">
<div class="row">

<!-- SIDEBAR -->
<div class="col-md-2 sidebar p-0">
<h5 class="text-white text-center py-3 border-bottom">ADMIN PANEL</h5>

<a href="dashboard.php">📊Dashboard</a>
<a href="add_service.php">➕ Manage Services</a>
<a href="view_users.php">👤 Users</a>
<a class="active" href="view_providers.php">👷 Providers</a>
<a href="view_bookings.php">📋 Bookings</a>
<a href="manage_support.php">💬 Support Requests</a>
<a href="../logout.php">🚪 Logout</a>
</div>

<!-- MAIN CONTENT -->
<div class="col-md-10 p-4">

<h3 class="mb-4">Service Providers</h3>

<div class="card shadow">
<div class="card-body">

<table class="table table-bordered table-striped table-hover">
<thead class="table-dark">
<tr>
    <th>ID</th>
    <th>Name</th>
    <th>Email</th>
    <th>Area</th>
    <th>Service</th>
    <th>Availability</th>
    <th>Status</th>
    <th>Action</th>
</tr>
</thead>
<tbody>

<?php
if (mysqli_num_rows($providers) > 0) {
    while ($p = mysqli_fetch_assoc($providers)) {
?>

<tr>
<td><?= $p['user_id'] ?></td>
<td><?= htmlspecialchars($p['name']) ?></td>
<td><?= htmlspecialchars($p['email']) ?></td>
<td><?= htmlspecialchars($p['area']) ?></td>

<td>
<?php
if (!empty($p['service_name'])) {
    echo htmlspecialchars($p['service_name']);
} else {
    echo "<span class='text-muted'>Not selected</span>";
}
?>
</td>

<td>
<?php
if ($p['availability'] == 'yes') {
    echo "<span class='badge bg-success'>Available</span>";
} elseif ($p['availability'] == 'no') {
    echo "<span class='badge bg-danger'>Not Available</span>";
} else {
    echo "<span class='badge bg-secondary'>N/A</span>";
}
?>
</td>

<td>
<?php
if ($p['status'] == 'approved') {
    echo "<span class='badge bg-success'>Approved</span>";
} elseif ($p['status'] == 'pending') {
    echo "<span class='badge bg-warning text-dark'>Pending</span>";
} else {
    echo "<span class='badge bg-danger'>Rejected</span>";
}
?>
</td>

<td>

<?php if($p['status']=='pending'){ ?>

<a href="approve_provider.php?id=<?= $p['user_id'] ?>" 
class="btn btn-success btn-sm">Approve</a>

<a href="reject_provider.php?id=<?= $p['user_id'] ?>" 
class="btn btn-danger btn-sm">Reject</a>

<?php } else { ?>

<span class="text-muted">No Action</span>

<?php } ?>

</td>

</tr>

<?php
    }
} else {
?>

<tr>
<td colspan="8" class="text-center text-muted">No providers found</td>
</tr>

<?php } ?>

</tbody>
</table>

</div>
</div>

</div>
</div>
</div>

</body>
</html>