<?php
session_start();
include "../config/db.php";

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header("Location: ../login.php");
    exit;
}

/* DELETE USER OR PROVIDER (Admin Cannot Delete Admin) */
if (isset($_GET['delete'])) {

    $id = intval($_GET['delete']);

    $check = mysqli_query($conn, "SELECT role FROM users WHERE user_id=$id");
    $row = mysqli_fetch_assoc($check);

    // Only delete if role is user or provider
    if ($row && ($row['role'] == 'user' || $row['role'] == 'provider')) {

        mysqli_query($conn, "DELETE FROM user_address WHERE user_id=$id");
        mysqli_query($conn, "DELETE FROM users WHERE user_id=$id");
    }

    header("Location: view_users.php");
    exit;
}

$users = mysqli_query($conn, "SELECT * FROM users ORDER BY user_id DESC");
?>

<!DOCTYPE html>
<html>
<head>
<title>Manage Users</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

<style>
body { background:#f4f6f9; }
.sidebar {
    min-height:100vh;
    background:#212529;
    position:sticky;
    top:0;
}
.sidebar a {
    color:#adb5bd;
    display:block;
    padding:12px 15px;
    text-decoration:none;
}
.sidebar a:hover {
    background:#343a40;
    color:#fff;
}
</style>
</head>
<body>

<div class="container-fluid">
<div class="row">

<!-- SIDEBAR -->
<div class="col-md-2 sidebar p-0">
<h5 class="text-white text-center py-3 border-bottom">ADMIN PANEL</h5>

<a class="<?= ($currunt=='dashboard.php')? 'active':'' ?>" href="dashboard.php">📊Dashboard</a>
<a class="<?= ($currunt=='add_service.php')? 'active':''?>"href="add_service.php">➕ Manage Services</a>
<a class="<?= ($currunt=='view_users.php')? 'active':''?>"href="view_users.php">👤 Users</a>
<a class="<?= ($currunt=='view_providers.php')? 'active':''?>"href="view_providers.php">👷 Providers</a>
<a class="<?= ($currunt=='view_bookings.php')? 'active':''?>"href="view_bookings.php">📋 Bookings</a>
<a class="<?= ($currunt=='manage_support.php')? 'active':''?>"href="manage_support.php">💬 Support Requests </a>
<a href="../logout.php">🚪 Logout</a>
</div>

<!-- MAIN CONTENT -->
<div class="col-md-10 p-4">

<h3 class="mb-4">Manage Users & Providers</h3>

<div class="card shadow">
<div class="card-body">

<table class="table table-bordered table-striped">
<thead class="table-dark">
<tr>
    <th>ID</th>
    <th>Name</th>
    <th>Email</th>
    <th>Area</th>
    <th>Role</th>
    <th>Address</th>
    <th>Actions</th>
</tr>
</thead>

<tbody>

<?php while($u = mysqli_fetch_assoc($users)): ?>
<tr>
<td><?= $u['user_id'] ?></td>
<td><?= htmlspecialchars($u['name']) ?></td>
<td><?= htmlspecialchars($u['email']) ?></td>
<td><?= htmlspecialchars($u['area']) ?></td>

<td>
<?php
if($u['role']=='admin'){
    echo '<span class="badge bg-primary">Admin</span>';
}elseif($u['role']=='provider'){
    echo '<span class="badge bg-warning text-dark">Provider</span>';
}else{
    echo '<span class="badge bg-info">User</span>';
}
?>
</td>

<td>
<a href="view_address.php?id=<?= $u['user_id'] ?>"
   class="btn btn-sm btn-secondary">
   View Address
</a>
</td>

<td>
<?php if($u['role']=='user' || $u['role']=='provider'): ?>
    <a href="edit_user.php?id=<?= $u['user_id'] ?>"
       class="btn btn-sm btn-success">
       Edit
    </a>

    <a href="view_users.php?delete=<?= $u['user_id'] ?>"
       class="btn btn-sm btn-danger"
       onclick="return confirm('Delete this record?');">
       Delete
    </a>
<?php else: ?>
    <span class="text-muted">Protected</span>
<?php endif; ?>
</td>

</tr>
<?php endwhile; ?>

</tbody>
</table>

</div>
</div>

</div>
</div>
</div>

</body>
</html>