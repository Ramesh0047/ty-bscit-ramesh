<?php
session_start();
include "../config/db.php";

if(!isset($_SESSION['user_id'])){
    header("Location: ../login.php");
    exit;
}

$user_id = $_SESSION['user_id'];
$role = $_SESSION['role'];

$booking_id = $_GET['booking_id'];


/* SEND MESSAGE */
if(isset($_POST['send'])){

$message = mysqli_real_escape_string($conn,$_POST['message']);
$image = "";

if(!empty($_FILES['image']['name'])){

$targetDir = "../uploads/chat/";

if(!is_dir($targetDir)){
mkdir($targetDir,0777,true);
}

$image = time()."_".$_FILES['image']['name'];

move_uploaded_file($_FILES['image']['tmp_name'],$targetDir.$image);

}

mysqli_query($conn,"
INSERT INTO messages(booking_id,sender_role,message,image)
VALUES('$booking_id','$role','$message','$image')
");

header("Location: chat.php?booking_id=".$booking_id);
exit;
}


/* MARK MESSAGES AS SEEN */

mysqli_query($conn,"
UPDATE messages
SET is_seen=1
WHERE booking_id='$booking_id'
AND sender_role!='$role'
");

?>
<!DOCTYPE html>
<html>
<head>

<title>Service Chat</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

<style>

body{
background:#f4f6f9;
}

.chat-container{
max-width:700px;
margin:auto;
margin-top:30px;
}

.chat-box{
height:400px;
overflow-y:auto;
background:white;
padding:15px;
border-radius:10px;
box-shadow:0 0 10px rgba(0,0,0,0.1);
}

.msg-user{
background:#d1ffd6;
padding:10px;
border-radius:10px;
margin:6px;
max-width:60%;
margin-left:auto;
text-align:right;
}

.msg-provider{
background:#f1f1f1;
padding:10px;
border-radius:10px;
margin:6px;
max-width:60%;
}

.msg img{
margin-top:5px;
border-radius:6px;
}

</style>

</head>

<body>

<div class="chat-container">

<h4 class="mb-3">💬 Service Chat</h4>

<div class="chat-box" id="chat-box">

<?php

$q = mysqli_query($conn,"
SELECT * FROM messages
WHERE booking_id='$booking_id'
ORDER BY sent_at ASC
");

while($m=mysqli_fetch_assoc($q)){

$class = ($m['sender_role']=="user") ? "msg-user" : "msg-provider";

echo "<div class='$class'>";

if($m['message']){
echo htmlspecialchars($m['message']);
}

if($m['image']){
echo "<br><img src='../uploads/chat/".$m['image']."' width='150'>";
}

echo "<br><small style='color:gray'>".$m['sent_at']."</small>";

echo "</div>";

}

?>

</div>

<form method="POST" enctype="multipart/form-data" class="mt-3 d-flex">

<input type="text" name="message" class="form-control me-2" placeholder="Type message...">

<input type="file" name="image" class="form-control me-2">

<button name="send" class="btn btn-primary">Send</button>

</form>

</div>

<script>

/* AUTO REFRESH CHAT */

setInterval(function(){

fetch("chat.php?booking_id=<?php echo $booking_id; ?>")
.then(res => res.text())
.then(data => {

let parser = new DOMParser();
let htmlDoc = parser.parseFromString(data, "text/html");

let newChat = htmlDoc.getElementById("chat-box").innerHTML;

document.getElementById("chat-box").innerHTML = newChat;

});

},2000);

</script>

</body>
</html>