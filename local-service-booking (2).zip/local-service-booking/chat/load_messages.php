<?php
include "../config/db.php";

$booking_id = $_GET['booking_id'];

$q = mysqli_query($conn,"
SELECT * FROM messages
WHERE booking_id='$booking_id'
ORDER BY sent_at ASC
");

while($m=mysqli_fetch_assoc($q)){

$class = $m['sender_role']=="user" ? "msg-user" : "msg-provider";

echo "<div class='$class'>";

echo $m['message'];

if($m['image']){
echo "<br><img src='../uploads/chat/".$m['image']."' width='120'>";
}

echo "</div>";
}
?>