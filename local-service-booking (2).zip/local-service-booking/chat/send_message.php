<?php
session_start();
include "../config/db.php";

$booking_id = $_POST['booking_id'];
$message = $_POST['message'];
$role = $_SESSION['role'];

$imagePath = "";

if(!empty($_FILES['image']['name'])){

$target = "../uploads/chat/";
$imagePath = time().$_FILES['image']['name'];

move_uploaded_file($_FILES['image']['tmp_name'],$target.$imagePath);

}

mysqli_query($conn,"
INSERT INTO messages(booking_id,sender_role,message,image)
VALUES('$booking_id','$role','$message','$imagePath')
");
?>