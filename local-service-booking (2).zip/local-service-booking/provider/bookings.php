<?php
session_start();
include "../config/db.php";

if (!isset($_SESSION['user_id']) || $_SESSION['role']!='provider'){
    header("Location: ../login.php");
    exit;
}

$user_id = $_SESSION['user_id'];

/* GET PROVIDER ID */
$getProvider = mysqli_query($conn,"
SELECT provider_id 
FROM service_providers 
WHERE user_id='$user_id'
");

$providerData = mysqli_fetch_assoc($getProvider);
$provider_id = $providerData['provider_id'];


/* AUTO CREATE INVOICE */
$missingInvoices = mysqli_query($conn,"
SELECT b.booking_id, s.price
FROM bookings b
JOIN services s ON b.service_id = s.service_id
LEFT JOIN invoices i ON b.booking_id = i.booking_id
WHERE b.provider_id='$provider_id'
AND b.status='completed'
AND i.booking_id IS NULL
");

while($row = mysqli_fetch_assoc($missingInvoices)){
    $booking_id = $row['booking_id'];
    $price = $row['price'];

    mysqli_query($conn,"
    INSERT INTO invoices (booking_id, amount)
    VALUES ('$booking_id','$price')
    ");
}


/* UPDATE STATUS */
if(isset($_GET['id'],$_GET['status'])){

$id = (int)$_GET['id'];
$status = $_GET['status'];

mysqli_query($conn,"
UPDATE bookings 
SET status='$status'
WHERE booking_id='$id'
AND provider_id='$provider_id'
");

header("Location: bookings.php");
exit;
}


/* FETCH BOOKINGS */
$bookings = mysqli_query($conn,"
SELECT b.*,u.name,s.service_name
FROM bookings b
JOIN users u ON b.user_id=u.user_id
JOIN services s ON b.service_id=s.service_id
WHERE b.provider_id='$provider_id'
ORDER BY b.booking_id DESC
");
?>

<!DOCTYPE html>
<html>
<head>
<title>Provider Bookings</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet"
href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

<style>

body{background:#f4f6f9;}

.sidebar{
min-height:100vh;
background:#0d6efd;
}

.sidebar a{
color:white;
padding:12px;
display:block;
text-decoration:none;
}

.sidebar a:hover{
background:#0b5ed7;
}

.sidebar i{margin-right:8px;}

</style>

</head>

<body>

<div class="container-fluid">
<div class="row">

<?php include "sidebar.php"; ?>

<div class="col-md-10 p-4">

<h3>Bookings</h3>

<table class="table table-bordered table-hover mt-3">

<tr class="table-dark">
<th>Date</th>
<th>User</th>
<th>Service</th>
<th>Status</th>
<th>Action</th>
</tr>

<?php while($b=mysqli_fetch_assoc($bookings)){ ?>

<tr>

<td><?= $b['booking_date'] ?></td>
<td><?= $b['name'] ?></td>
<td><?= $b['service_name'] ?></td>

<td><?= ucfirst($b['status']) ?></td>

<td>

<?php if($b['status']=='requested'){ ?>

<a href="?id=<?= $b['booking_id'] ?>&status=accepted" 
class="btn btn-success btn-sm">Accept</a>

<a href="?id=<?= $b['booking_id'] ?>&status=rejected" 
class="btn btn-danger btn-sm">Reject</a>

<?php } elseif($b['status']=='accepted'){ ?>

<a href="?id=<?= $b['booking_id'] ?>&status=completed" 
class="btn btn-primary btn-sm">Complete</a>

<?php } ?>

<a href="../chat/chat.php?booking_id=<?= $b['booking_id'] ?>" 
class="btn btn-dark btn-sm">
💬 Chat
</a>

</td>

</tr>

<?php } ?>

</table>

</div>
</div>
</div>

</body>
</html>