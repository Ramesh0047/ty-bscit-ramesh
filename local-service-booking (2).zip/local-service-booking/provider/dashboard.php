<?php
session_start();
include "../config/db.php";

if (!isset($_SESSION['user_id']) || $_SESSION['role']!='provider'){
    header("Location: ../login.php");
    exit;
}

$user_id = $_SESSION['user_id'];

$provider = mysqli_fetch_assoc(
mysqli_query($conn,"SELECT * FROM service_providers WHERE user_id='$user_id'")
);

$provider_id = $provider['provider_id'];

/* STATS */

$total = mysqli_fetch_assoc(mysqli_query($conn,
"SELECT COUNT(*) c FROM bookings WHERE provider_id='$provider_id'"))['c'];

$completed = mysqli_fetch_assoc(mysqli_query($conn,
"SELECT COUNT(*) c FROM bookings WHERE provider_id='$provider_id' AND status='completed'"))['c'];

$pending = mysqli_fetch_assoc(mysqli_query($conn,
"SELECT COUNT(*) c FROM bookings WHERE provider_id='$provider_id' AND status='pending'"))['c'];

$today = mysqli_fetch_assoc(mysqli_query($conn,
"SELECT COUNT(*) c FROM bookings 
WHERE provider_id='$provider_id'
AND DATE(booking_date)=CURDATE()"))['c'];

$earnings = mysqli_fetch_assoc(mysqli_query($conn,"
SELECT SUM(i.amount) total
FROM invoices i
JOIN bookings b ON i.booking_id=b.booking_id
WHERE b.provider_id='$provider_id'
"))['total'] ?? 0;

/* ANALYTICS */

$jobs_data=[];
$earnings_data=[];

$q=mysqli_query($conn,"
SELECT 
MONTH(b.booking_date) m,
COUNT(b.booking_id) jobs,
SUM(i.amount) earnings
FROM bookings b
LEFT JOIN invoices i ON b.booking_id=i.booking_id
WHERE b.provider_id='$provider_id'
GROUP BY MONTH(b.booking_date)
");

while($row=mysqli_fetch_assoc($q)){
$jobs_data[]=$row['jobs'];
$earnings_data[]=$row['earnings'];
}

?>

<!DOCTYPE html>
<html>
<head>

<title>Provider Dashboard</title>

<link rel="stylesheet"
href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">

<link rel="stylesheet"
href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<style>

body{background:#f4f6f9;}

.sidebar{
min-height:100vh;
background:#0d6efd;
}

.sidebar a{
color:white;
padding:12px;
display:block;
text-decoration:none;
}

.sidebar a:hover{
background:#0b5ed7;
}

.sidebar i{
margin-right:8px;
}

.card-box{
border-radius:12px;
padding:25px;
color:white;
box-shadow:0 4px 10px rgba(0,0,0,0.1);
}

.bg1{background:linear-gradient(45deg,#007bff,#00c6ff);}
.bg2{background:linear-gradient(45deg,#28a745,#7ed56f);}
.bg3{background:linear-gradient(45deg,#ffc107,#ff9800);}
.bg4{background:linear-gradient(45deg,#343a40,#6c757d);}
.bg5{background:linear-gradient(45deg,#6f42c1,#b794f4);}

</style>

</head>

<body>

<div class="container-fluid">
<div class="row">

<!-- SIDEBAR -->

<?php include "sidebar.php"; ?>


<div class="col-md-10 p-4">

<h3 class="mb-4">Provider Dashboard</h3>

<!-- CARDS -->

<div class="row g-4">

<div class="col-md-3">
<div class="card-box bg1">
<i class="fa fa-briefcase"></i>
<h5>Total Jobs</h5>
<h2><?= $total ?></h2>
</div>
</div>

<div class="col-md-3">
<div class="card-box bg2">
<i class="fa fa-check-circle"></i>
<h5>Completed</h5>
<h2><?= $completed ?></h2>
</div>
</div>

<div class="col-md-3">
<div class="card-box bg3">
<i class="fa fa-clock"></i>
<h5>Pending</h5>
<h2><?= $pending ?></h2>
</div>
</div>

<div class="col-md-3">
<div class="card-box bg4">
<i class="fa fa-calendar-day"></i>
<h5>Today's Jobs</h5>
<h2><?= $today ?></h2>
</div>
</div>

<div class="col-md-3 mt-4">
<div class="card-box bg5">
<i class="fa fa-rupee-sign"></i>
<h5>Total Earnings</h5>
<h2>₹<?= $earnings ?></h2>
</div>
</div>

</div>

<!-- ANALYTICS -->

<div class="card mt-5 p-4">

<h4>Analytics</h4>

<canvas id="chart"></canvas>

</div>

</div>
</div>
</div>

<script>

var ctx=document.getElementById('chart');

new Chart(ctx,{
type:'bar',

data:{
labels:['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'],

datasets:[
{
label:'Monthly Jobs',
data:<?= json_encode($jobs_data) ?>,
backgroundColor:'#007bff'
},
{
label:'Monthly Earnings',
data:<?= json_encode($earnings_data) ?>,
backgroundColor:'#28a745'
}
]
}

});

</script>

</body>
</html>