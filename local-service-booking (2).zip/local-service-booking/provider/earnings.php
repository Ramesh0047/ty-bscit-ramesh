<?php
session_start();
include "../config/db.php";

if (!isset($_SESSION['user_id']) || $_SESSION['role']!='provider'){
    header("Location: ../login.php");
    exit;
}

$user_id = $_SESSION['user_id'];

/* GET PROVIDER */
$getProvider = mysqli_query($conn,"
SELECT provider_id
FROM service_providers
WHERE user_id='$user_id'
");

$providerData = mysqli_fetch_assoc($getProvider);
$provider_id = $providerData['provider_id'];


/* TOTAL EARNINGS */

$totalQuery = mysqli_query($conn,"
SELECT 
SUM(i.amount) total_earnings,
COUNT(i.invoice_id) total_jobs
FROM invoices i
JOIN bookings b ON i.booking_id=b.booking_id
WHERE b.provider_id='$provider_id'
");

$totalData = mysqli_fetch_assoc($totalQuery);

$total_earnings = $totalData['total_earnings'] ?? 0;
$total_jobs = $totalData['total_jobs'] ?? 0;


/* TODAY */

$today = mysqli_fetch_assoc(mysqli_query($conn,"
SELECT SUM(i.amount) t
FROM invoices i
JOIN bookings b ON i.booking_id=b.booking_id
WHERE b.provider_id='$provider_id'
AND DATE(i.generated_at)=CURDATE()
"))['t'] ?? 0;


/* WEEK */

$week = mysqli_fetch_assoc(mysqli_query($conn,"
SELECT SUM(i.amount) t
FROM invoices i
JOIN bookings b ON i.booking_id=b.booking_id
WHERE b.provider_id='$provider_id'
AND YEARWEEK(i.generated_at)=YEARWEEK(CURDATE())
"))['t'] ?? 0;


/* MONTH */

$month = mysqli_fetch_assoc(mysqli_query($conn,"
SELECT SUM(i.amount) t
FROM invoices i
JOIN bookings b ON i.booking_id=b.booking_id
WHERE b.provider_id='$provider_id'
AND MONTH(i.generated_at)=MONTH(CURDATE())
"))['t'] ?? 0;


/* MONTHLY EARNINGS TABLE */

$monthlyQuery = mysqli_query($conn,"
SELECT 
DATE_FORMAT(i.generated_at,'%M %Y') month,
SUM(i.amount) monthly_total
FROM invoices i
JOIN bookings b ON i.booking_id=b.booking_id
WHERE b.provider_id='$provider_id'
GROUP BY DATE_FORMAT(i.generated_at,'%Y-%m')
ORDER BY i.generated_at DESC
");


/* INVOICE HISTORY */

$invoiceQuery = mysqli_query($conn,"
SELECT 
i.invoice_id,
i.amount,
i.generated_at,
u.name,
s.service_name
FROM invoices i
JOIN bookings b ON i.booking_id=b.booking_id
JOIN users u ON b.user_id=u.user_id
JOIN services s ON b.service_id=s.service_id
WHERE b.provider_id='$provider_id'
ORDER BY i.generated_at DESC
");

?>

<!DOCTYPE html>
<html>
<head>

<title>Earnings Dashboard</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

<link rel="stylesheet"
href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<style>

body{background:#f4f6f9;}

.sidebar{
min-height:100vh;
background:#0d6efd;
}

.sidebar a{
color:white;
padding:12px;
display:block;
text-decoration:none;
}

.sidebar a:hover{
background:#0b5ed7;
}

.sidebar i{margin-right:8px;}

.card-box{
border-radius:12px;
padding:25px;
color:#fff;
box-shadow:0 4px 15px rgba(0,0,0,0.1);
}

.bg1{background:linear-gradient(45deg,#007bff,#00c6ff);}
.bg2{background:linear-gradient(45deg,#28a745,#7ed56f);}
.bg3{background:linear-gradient(45deg,#ffc107,#ff9800);}
.bg4{background:linear-gradient(45deg,#343a40,#6c757d);}
.bg5{background:linear-gradient(45deg,#6f42c1,#b794f4);}

</style>

</head>

<body>

<div class="container-fluid">
<div class="row">

<?php include "sidebar.php"; ?>

<div class="col-md-10 p-4">

<h3>Earnings Dashboard</h3>

<!-- EARNING CARDS -->

<div class="row mt-4 g-3">

<div class="col-md-3">
<div class="card-box bg-success">
<h6>Today Earnings</h6>
<h3>₹ <?= number_format($today,2) ?></h3>
</div>
</div>

<div class="col-md-3">
<div class="card-box bg-primary">
<h6>This Week</h6>
<h3>₹ <?= number_format($week,2) ?></h3>
</div>
</div>

<div class="col-md-3">
<div class="card-box bg-warning">
<h6>This Month</h6>
<h3>₹ <?= number_format($month,2) ?></h3>
</div>
</div>

<div class="col-md-3">
<div class="card-box bg-dark">
<h6>Total Earnings</h6>
<h3>₹ <?= number_format($total_earnings,2) ?></h3>
</div>
</div>

<div class="col-md-3">
<div class="card-box bg-info">
<h6>Total Completed Jobs</h6>
<h3><?= $total_jobs ?></h3>
</div>
</div>

</div>


<!-- GRAPH -->

<div class="card mt-5 p-4">

<h4>Monthly Earnings Graph</h4>

<canvas id="earnChart"></canvas>

</div>


<!-- MONTHLY TABLE -->

<h4 class="mt-5">Monthly Earnings</h4>

<table class="table table-bordered mt-3">

<tr class="table-dark">
<th>Month</th>
<th>Total Earnings</th>
</tr>

<?php while($m=mysqli_fetch_assoc($monthlyQuery)){ ?>

<tr>
<td><?= $m['month'] ?></td>
<td>₹ <?= number_format($m['monthly_total'],2) ?></td>
</tr>

<?php } ?>

</table>


<!-- INVOICE HISTORY -->

<h4 class="mt-5">Invoice History</h4>

<table class="table table-bordered">

<tr class="table-dark">
<th>ID</th>
<th>Customer</th>
<th>Service</th>
<th>Amount</th>
<th>Date</th>
</tr>

<?php while($inv=mysqli_fetch_assoc($invoiceQuery)){ ?>

<tr>

<td><?= $inv['invoice_id'] ?></td>

<td><?= $inv['name'] ?></td>

<td><?= $inv['service_name'] ?></td>

<td>₹ <?= number_format($inv['amount'],2) ?></td>

<td><?= date("d M Y",strtotime($inv['generated_at'])) ?></td>

</tr>

<?php } ?>

</table>

</div>
</div>
</div>

<script>

/* GRAPH DATA */

var labels=[];
var data=[];

<?php

$chartQuery=mysqli_query($conn,"
SELECT 
DATE_FORMAT(i.generated_at,'%b') month,
SUM(i.amount) total
FROM invoices i
JOIN bookings b ON i.booking_id=b.booking_id
WHERE b.provider_id='$provider_id'
GROUP BY MONTH(i.generated_at)
");

while($c=mysqli_fetch_assoc($chartQuery)){

echo "labels.push('".$c['month']."');";
echo "data.push(".$c['total'].");";

}

?>

new Chart(document.getElementById("earnChart"),{

type:'line',

data:{
labels:labels,
datasets:[{
label:'Monthly Earnings',
data:data,
borderColor:'green',
fill:false
}]
}

});

</script>

</body>
</html>