<?php
session_start();
include "../config/db.php";

if (!isset($_SESSION['user_id']) || $_SESSION['role']!='provider'){
    header("Location: ../login.php");
    exit;
}

$user_id = $_SESSION['user_id'];
$services = mysqli_query($conn,"SELECT * FROM services WHERE status='active'");

if(isset($_POST['save'])){
    $service_id = (int)$_POST['service_id'];
    $availability = $_POST['availability'];

    $check = mysqli_query($conn,"SELECT * FROM service_providers WHERE user_id='$user_id'");

    if(mysqli_num_rows($check)>0){
        mysqli_query($conn,"UPDATE service_providers SET service_id='$service_id',availability='$availability' WHERE user_id='$user_id'");
    }else{
        mysqli_query($conn,"INSERT INTO service_providers (user_id,service_id,availability) VALUES ('$user_id','$service_id','$availability')");
    }

    header("Location: select_service.php");
    exit;
}

$currentService = mysqli_fetch_assoc(mysqli_query($conn,"SELECT * FROM service_providers WHERE user_id='$user_id'"));
?>

<!DOCTYPE html>
<html>
<head>
<title>Select Service</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet"
href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<style>

body{background:#f4f6f9;}

.sidebar{
min-height:100vh;
background:#0d6efd;
}

.sidebar a{
color:white;
padding:12px;
display:block;
text-decoration:none;
}

.sidebar a:hover{
background:#0b5ed7;
}

.sidebar i{margin-right:8px;}

</style>
</head>
<body>

<div class="container-fluid">
<div class="row">

<?php include "sidebar.php"; ?>

<div class="col-md-10 p-4">
<h3>Select Your Service</h3>

<div class="row mt-4">
<?php while($s=mysqli_fetch_assoc($services)){ ?>
<div class="col-md-4">
<div class="card p-3 shadow">
<h5><?= $s['service_name'] ?></h5>
<form method="POST">
<input type="hidden" name="service_id" value="<?= $s['service_id'] ?>">
<select name="availability" class="form-select my-2">
<option value="yes">Available</option>
<option value="no">Not Available</option>
</select>
<button type="submit" name="save" class="btn btn-primary w-100">
Select
</button>
</form>
</div>
</div>
<?php } ?>
</div>

</div>
</div>
</div>

</body>
</html>