<?php
$current = basename($_SERVER['PHP_SELF']);
?>

<div class="col-md-2 sidebar p-0">

<h4 class="text-center py-3 border-bottom">PROVIDER</h4>

<a href="dashboard.php"><i class="fa fa-home"></i> Dashboard</a>
<a href="select_service.php"><i class="fa fa-tools"></i> My Service</a>
<a href="bookings.php"><i class="fa fa-calendar"></i> Bookings</a>
<a href="time_slots.php"><i class="fa fa-clock"></i> Time Slots</a>
<a href="earnings.php"><i class="fa fa-rupee-sign"></i> Earnings</a>
<a href="../logout.php"><i class="fa fa-sign-out-alt"></i> Logout</a>

</div>
