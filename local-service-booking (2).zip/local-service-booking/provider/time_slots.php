<?php
session_start();
include "../config/db.php";

$user_id = $_SESSION['user_id'];

$provider = mysqli_fetch_assoc(
mysqli_query($conn,"SELECT * FROM service_providers WHERE user_id='$user_id'")
);

$provider_id = $provider['provider_id'];

if(isset($_POST['add'])){
$slot=$_POST['slot'];

mysqli_query($conn,"
INSERT INTO provider_slots(provider_id,slot_time)
VALUES('$provider_id','$slot')
");
}

$slots=mysqli_query($conn,"
SELECT * FROM provider_slots WHERE provider_id='$provider_id'
");
?>

<!DOCTYPE html>
<html>
<head>

<title>Service Time Slots</title>

<link rel="stylesheet"
href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">

<link rel="stylesheet"
href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

<style>

body{background:#f4f6f9;}

.sidebar{
min-height:100vh;
background:#0d6efd;
}

.sidebar a{
color:white;
padding:12px;
display:block;
text-decoration:none;
}

.sidebar a:hover{
background:#0b5ed7;
}

.sidebar i{margin-right:8px;}

</style>

</head>

<body>

<div class="container-fluid">
<div class="row">

<!-- SIDEBAR -->
 <?php include "sidebar.php"; ?>


<div class="col-md-10 p-4">

<h3>Service Time Slots</h3>

<form method="post" class="row g-2">

<div class="col-md-3">
<input type="time" name="slot" class="form-control" required>
</div>

<div class="col-md-2">
<button name="add" class="btn btn-primary">Add Slot</button>
</div>

</form>

<hr>

<table class="table table-bordered">

<tr>
<th>ID</th>
<th>Time</th>
<th>Status</th>
</tr>

<?php while($s=mysqli_fetch_assoc($slots)){ ?>

<tr>
<td><?= $s['slot_id'] ?></td>
<td><?= $s['slot_time'] ?></td>
<td><?= $s['status'] ?></td>
</tr>

<?php } ?>

</table>

</div>
</div>
</div>

</body>
</html>