/* THIS IS ADVANCED SQL FILE FOR URBUN COMPANI LIKE STRUCURE FILE */
/*
ALTER TABLE bookings 
ADD booking_date DATE,
ADD booking_time TIME,
ADD booking_type VARCHAR(20),
ADD admin_commission DECIMAL(10,2),
ADD provider_earning DECIMAL(10,2);


CREATE TABLE provider_wallet(
provider_id INT PRIMARY KEY,
balance DECIMAL(10,2) DEFAULT 0
);

CREATE TABLE reviews(
id INT AUTO_INCREMENT PRIMARY KEY,
booking_id INT,
user_id INT,
provider_id INT,
rating INT,
review TEXT,
created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE notifications(
id INT AUTO_INCREMENT PRIMARY KEY,
user_id INT,
message TEXT,
status VARCHAR(20) DEFAULT 'unread',
created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE provider_portfolio(
id INT AUTO_INCREMENT PRIMARY KEY,
provider_id INT,
image VARCHAR(255),
description TEXT
);

CREATE TABLE coupons(
id INT AUTO_INCREMENT PRIMARY KEY,
code VARCHAR(50),
discount INT,
expiry_date DATE
);

CREATE TABLE booking_chat(
id INT AUTO_INCREMENT PRIMARY KEY,
booking_id INT,
sender_id INT,
message TEXT,
created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

UPDATE TABLE users (
id INT AUTO_INCREMENT PRIMARY KEY,
name VARCHAR(100),
email VARCHAR(100),
phone VARCHAR(20),
password VARCHAR(255),
role ENUM('user','provider','admin'),
created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

UPDATE TABLE services (
id INT AUTO_INCREMENT PRIMARY KEY,
service_name VARCHAR(100),
price DECIMAL(10,2),
description TEXT,
icon VARCHAR(255)
);

CREATE TABLE providers (
id INT AUTO_INCREMENT PRIMARY KEY,
user_id INT,
service_id INT,
experience INT,
address TEXT,
rating DECIMAL(3,2) DEFAULT 0,
status VARCHAR(20) DEFAULT 'Pending'
);

UPDATE TABLE bookings (
id INT AUTO_INCREMENT PRIMARY KEY,
user_id INT,
provider_id INT,
service_id INT,
booking_date DATE,
booking_time TIME,
price DECIMAL(10,2),
admin_commission DECIMAL(10,2),
provider_earning DECIMAL(10,2),
booking_type VARCHAR(20),
status VARCHAR(50) DEFAULT 'Pending',
created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE payments (
id INT AUTO_INCREMENT PRIMARY KEY,
booking_id INT,
amount DECIMAL(10,2),
payment_method VARCHAR(50),
payment_status VARCHAR(20),
transaction_id VARCHAR(100),
created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE reviews (
id INT AUTO_INCREMENT PRIMARY KEY,
booking_id INT,
user_id INT,
provider_id INT,
rating INT,
review TEXT,
created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE provider_wallet (
provider_id INT PRIMARY KEY,
balance DECIMAL(10,2) DEFAULT 0
);

UPDATE TABLE notifications (
id INT AUTO_INCREMENT PRIMARY KEY,
user_id INT,
message TEXT,
status VARCHAR(20) DEFAULT 'unread',
created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE booking_chat (
id INT AUTO_INCREMENT PRIMARY KEY,
booking_id INT,
sender_id INT,
message TEXT,
created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

*/