<?php
session_start();
include "../config/db.php";

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'user') {
    header("Location: ../login.php");
    exit;
}

$user_id = $_SESSION['user_id'];
$msg = "";

/* Fetch Active Services */
$services = mysqli_query($conn, "
    SELECT s.*, COUNT(sp.provider_id) as providers
    FROM services s
    LEFT JOIN service_providers sp 
        ON s.service_id = sp.service_id 
        AND sp.availability = 'yes'
    WHERE s.status='active'
    GROUP BY s.service_id
    ORDER BY s.service_name
");

if (!$services) {
    die("Service Query Error: " . mysqli_error($conn));
}

/* BOOK SERVICE */
if (isset($_POST['book'])) {

    $service_id   = intval($_POST['service_id']);
    $booking_date = $_POST['booking_date'] ?? '';
    $time_slot    = $_POST['time_slot'] ?? '';

    if (empty($booking_date) || empty($time_slot)) {

        $msg = "<div class='alert alert-danger'>
                Please select date and time.
                </div>";

    } 
    elseif (strtotime($booking_date . " " . $time_slot) <= time()) {

        $msg = "<div class='alert alert-danger'>
                Please select future date & time.
                </div>";

    } 
    else {

        /* Duplicate booking check (same user, same service, same date) */
        $checkBooking = mysqli_query($conn, "
            SELECT * FROM bookings
            WHERE user_id='$user_id'
            AND service_id='$service_id'
            AND booking_date='$booking_date'
            AND status IN ('requested','accepted')
        ");

        if (!$checkBooking) {
            die("Duplicate Check Error: " . mysqli_error($conn));
        }

        if (mysqli_num_rows($checkBooking) > 0) {

            $msg = "<div class='alert alert-warning'>
                    You already booked this service on this date.
                    </div>";

        } 
        else {

            /* Auto assign least busy provider */
            $providerQuery = mysqli_query($conn, "
                SELECT sp.provider_id,
                       COUNT(b.booking_id) as total_bookings
                FROM service_providers sp
                LEFT JOIN bookings b 
                    ON sp.provider_id = b.provider_id
                    AND b.booking_date = '$booking_date'
                WHERE sp.service_id = '$service_id'
                AND sp.availability = 'yes'
                GROUP BY sp.provider_id
                ORDER BY total_bookings ASC
                LIMIT 1
            ");

            if (!$providerQuery) {
                die("Provider Query Error: " . mysqli_error($conn));
            }

            if (mysqli_num_rows($providerQuery) > 0) {

                $provider = mysqli_fetch_assoc($providerQuery);
                $provider_id = $provider['provider_id'];

                /* Conflict check */
                $checkConflict = mysqli_query($conn, "
                    SELECT * FROM bookings
                    WHERE provider_id='$provider_id'
                    AND booking_date='$booking_date'
                    AND time_slot='$time_slot'
                    AND status IN ('requested','accepted')
                ");

                if (!$checkConflict) {
                    die("Conflict Check Error: " . mysqli_error($conn));
                }

                if (mysqli_num_rows($checkConflict) > 0) {

                    $msg = "<div class='alert alert-danger'>
                            This time slot is already booked.
                            Please select another time.
                            </div>";

                } 
                else {

                    $insert = mysqli_query($conn, "
                        INSERT INTO bookings 
                        (user_id, provider_id, service_id, booking_date, time_slot, status)
                        VALUES 
                        ('$user_id', '$provider_id', '$service_id', '$booking_date', '$time_slot', 'requested')
                    ");

                    if (!$insert) {
                        die("Insert Error: " . mysqli_error($conn));
                    }

                    $msg = "<div class='alert alert-success'>
                            Service booked successfully!
                            </div>";
                }

            } 
            else {
                $msg = "<div class='alert alert-danger'>
                        No provider available.
                        </div>";
            }
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Book Service</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
<script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
<style>
body { background:#f4f6f9; }
.sidebar { min-height:100vh; background:#198754; }
.sidebar a { color:#fff; padding:12px 15px; display:block; text-decoration:none; }
.sidebar a:hover, .sidebar a.active { background:#157347; }
.service-card { border-radius:15px; transition:0.3s; }
.service-card:hover { transform: translateY(-5px); }
.badge-available { background:#28a745; }
.badge-unavailable { background:#dc3545; }
</style>
</head>
<body>

<div class="container-fluid">
<div class="row">

<div class="col-md-2 sidebar p-0">
<h5 class="text-center py-3 border-bottom text-white">USER PANEL</h5>

<a class="<?= ($current=='dashboard.php')?'active':'' ?>" href="dashboard.php">🏠 Dashboard</a>
<a class="<?= ($current=='book_service.php')?'active':'' ?>" href="book_service.php">🛒 Book Service</a>
<a class="<?= ($current=='my_bookings.php')?'active':'' ?>" href="my_bookings.php">📋 My Bookings</a>
<a class="<?= ($current=='profile.php')?'active':'' ?>" href="profile.php">👤 My Profile</a>
<a class="<?= ($current=='support.php')?'active':'' ?> href="support.php">💬Support</a>
<a href="../logout.php">🚪 Logout</a>
</div>

<div class="col-md-10 p-4">
<h3 class="mb-4">Book a Service</h3>
<?= $msg ?>

<div class="row g-4">
<?php while ($s = mysqli_fetch_assoc($services)) { ?>
<div class="col-md-4">
<div class="card service-card shadow h-100">
<div class="card-body">

<h5><?= $s['service_name'] ?></h5>
<p class="text-muted"><?= $s['description'] ?? 'Professional service available' ?></p>

<?php if ($s['providers'] > 0) { ?>
<span class="badge badge-available mb-3">Available</span>

<form method="POST">
<input type="hidden" name="service_id" value="<?= $s['service_id'] ?>">

<div class="mb-2">
<label>Select Date</label>
<input type="text" id="datePicker<?= $s['service_id'] ?>" 
       name="booking_date" class="form-control" required>
</div>

<div class="mb-2">
<label>Select Time Slot</label>
<select name="time_slot" class="form-control" required>
<option value="">-- Select Time --</option>
<?php
for ($hour = 9; $hour < 18; $hour++) {
    $time = sprintf("%02d:00:00", $hour);
    echo "<option value='$time'>$hour:00 - ".($hour+1).":00</option>";
}
?>
</select>
</div>

<button type="submit" name="book" class="btn btn-primary w-100">
📌 Book Now
</button>
</form>

<script>
flatpickr("#datePicker<?= $s['service_id'] ?>", {
    minDate: "today",
    dateFormat: "Y-m-d"
});
</script>

<?php } else { ?>
<span class="badge badge-unavailable mb-3">Not Available</span>
<button class="btn btn-secondary w-100" disabled>Not Available</button>
<?php } ?>

</div>
</div>
</div>
<?php } ?>
</div>

</div>
</div>
</div>

</body>
</html>