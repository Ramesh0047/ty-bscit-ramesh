<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'user') {
    header("Location: ../login.php");
    exit;
}

include "../config/db.php";

$current = basename($_SERVER['PHP_SELF']);
$uid = $_SESSION['user_id'];

/* TOTAL BOOKINGS */
$stmt1 = $conn->prepare("SELECT COUNT(*) as c FROM bookings WHERE user_id=?");
$stmt1->bind_param("i", $uid);
$stmt1->execute();
$total = $stmt1->get_result()->fetch_assoc()['c'];

/* COMPLETED BOOKINGS */
$stmt2 = $conn->prepare("SELECT COUNT(*) as c FROM bookings WHERE user_id=? AND status='completed'");
$stmt2->bind_param("i", $uid);
$stmt2->execute();
$completed = $stmt2->get_result()->fetch_assoc()['c'];

/* FEEDBACK COUNT */
$stmt3 = $conn->prepare("
    SELECT COUNT(*) as c 
    FROM feedback f
    JOIN bookings b ON f.booking_id = b.booking_id
    WHERE b.user_id = ?
");
$stmt3->bind_param("i", $uid);
$stmt3->execute();
$feedbacks = $stmt3->get_result()->fetch_assoc()['c'];
?>

<!DOCTYPE html>
<html>
<head>
<title>User Dashboard</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

<style>
body { background:#f4f6f9; }

.sidebar {
    min-height:100vh;
    background:#198754;
}

.sidebar a {
    color:#fff;
    display:block;
    padding:12px 15px;
    text-decoration:none;
}

.sidebar a:hover, .sidebar a.active {
    background:#157347;
}

.box {
    border-radius:16px;
    padding:25px;
    color:#fff;
    height:100%;
    display:flex;
    flex-direction:column;
    justify-content:center;
    transition:0.3s ease;
}

.box:hover {
    transform: translateY(-5px);
}

.stat-number {
    font-size:32px;
    font-weight:bold;
    margin-top:10px;
}
</style>
</head>

<body>
<div class="container-fluid">
<div class="row">

<!-- SIDEBAR -->
<div class="col-md-2 sidebar p-0">
<h5 class="text-center py-3 border-bottom text-white">USER PANEL</h5>

<a class="<?= ($current=='dashboard.php')?'active':'' ?>" href="dashboard.php">🏠 Dashboard</a>
<a class="<?= ($current=='book_service.php')?'active':'' ?>" href="book_service.php">🛒 Book Service</a>
<a class="<?= ($current=='my_bookings.php')?'active':'' ?>" href="my_bookings.php">📋 My Bookings</a>
<a class="<?= ($current=='profile.php')?'active':'' ?>" href="profile.php">👤 My Profile</a>
<a class="<?= ($current=='support.php')?'active':'' ?> href="support.php">💬Support</a>
<a href="../logout.php">🚪 Logout</a>
</div>

<!-- MAIN CONTENT -->
<div class="col-md-10 p-4">

<h3 class="mb-4">Welcome 👋</h3>

<!-- ACTION CARDS -->
<div class="row g-4 mb-4">

    <div class="col-md-6">
        <a href="book_service.php" class="text-decoration-none">
            <div class="box bg-primary shadow">
                <h5>Book a Service</h5>
                <p class="mb-0">Request local services easily</p>
            </div>
        </a>
    </div>

    <div class="col-md-6">
        <a href="my_bookings.php" class="text-decoration-none">
            <div class="box bg-warning text-dark shadow">
                <h5>Track Bookings</h5>
                <p class="mb-0">Check service status</p>
            </div>
        </a>
    </div>

</div>

<!-- STATS -->
<div class="row g-4 mb-4">

    <div class="col-md-4">
        <div class="box bg-primary shadow">
            <h6>Total Bookings</h6>
            <div class="stat-number"><?= $total ?></div>
        </div>
    </div>

    <div class="col-md-4">
        <div class="box bg-success shadow">
            <h6>Completed</h6>
            <div class="stat-number"><?= $completed ?></div>
        </div>
    </div>

    <div class="col-md-4">
        <div class="box bg-warning text-dark shadow">
            <h6>Feedback Given</h6>
            <div class="stat-number"><?= $feedbacks ?></div>
        </div>
    </div>

</div>

<!-- INFO -->
<div class="row g-4">

    <a href="support.php" style="text-decoration:none;">
    <div class="card shadow p-4 mt-4 bg-success text-white" style="border-radius:15px;">
        <h4>Fast Support</h4>
        <p>Verified providers available for quick service</p>
    </div>
</a>

</div>

</div>
</div>
</div>
</body>
</html>