<?php
session_start();
include "../config/db.php";

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'user') {
    header("Location: ../login.php");
    exit;
}

$user_id = $_SESSION['user_id'];

/* FETCH BOOKINGS */

$stmt = $conn->prepare("
SELECT b.*, 
s.service_name, 
s.price,
i.amount
FROM bookings b
JOIN services s ON b.service_id = s.service_id
LEFT JOIN invoices i ON b.booking_id = i.booking_id
WHERE b.user_id=?
ORDER BY b.booking_id DESC
");

$stmt->bind_param("i",$user_id);
$stmt->execute();

$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html>
<head>

<title>My Bookings</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

<style>

body { background:#f4f6f9; }

.sidebar {
    min-height:100vh;
    background:#198754;
}

.sidebar a {
    color:#fff;
    display:block;
    padding:12px 15px;
    text-decoration:none;
}

.sidebar a:hover, .sidebar a.active {
    background:#157347;
}
</style>

</head>

<body>

<div class="container-fluid">
<div class="row">

<!-- SIDEBAR -->
<div class="col-md-2 sidebar p-0">
<h5 class="text-center py-3 border-bottom text-white">USER PANEL</h5>

<a class="<?= ($current=='dashboard.php')?'active':'' ?>" href="dashboard.php">🏠 Dashboard</a>
<a class="<?= ($current=='book_service.php')?'active':'' ?>" href="book_service.php">🛒 Book Service</a>
<a class="<?= ($current=='my_bookings.php')?'active':'' ?>" href="my_bookings.php">📋 My Bookings</a>
<a class="<?= ($current=='profile.php')?'active':'' ?>" href="profile.php">👤 My Profile</a>
<a class="<?= ($current=='support.php')?'active':'' ?> href="support.php">💬Support</a>
<a href="../logout.php">🚪 Logout</a>
</div>

<div class="col-md-10 p-4">

<h3>My Bookings</h3>

<table class="table table-bordered">

<tr class="table-dark">

<th>ID</th>
<th>Service</th>
<th>Date</th>
<th>Price</th>
<th>Status</th>
<th>Chat</th>

</tr>

<?php while($b=$result->fetch_assoc()){ ?>

<tr>

<td><?= $b['booking_id'] ?></td>
<td><?= $b['service_name'] ?></td>
<td><?= $b['booking_date'] ?></td>

<td class="text-success">

₹<?= number_format($b['amount'] ?? $b['price'],2) ?>

</td>

<td>

<span class="badge bg-primary">
<?= ucfirst($b['status']) ?>
</span>

</td>

<td>

<a href="../chat/chat.php?booking_id=<?= $b['booking_id'] ?>" 
class="btn btn-primary btn-sm">
💬 Chat
</a>

</td>

</tr>

<?php } ?>

</table>

</div>
</div>
</div>

</body>
</html>