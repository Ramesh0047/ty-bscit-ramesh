<?php
session_start();
include "../config/db.php";

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'user') {
    header("Location: ../login.php");
    exit;
}

$current = basename($_SERVER['PHP_SELF']);
$id = $_SESSION['user_id'];
$msg = "";

/* UPDATE PROFILE */
if(isset($_POST['update'])){

    $name = $_POST['name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $address = $_POST['address'];

    /* Update users table */
    $stmt = $conn->prepare("UPDATE users SET name=?, email=? WHERE user_id=?");
    $stmt->bind_param("ssi", $name, $email, $id);
    $stmt->execute();

    /* Check if address exists */
    $check = $conn->prepare("SELECT * FROM user_address WHERE user_id=?");
    $check->bind_param("i", $id);
    $check->execute();
    $result = $check->get_result();

    if($result->num_rows > 0){
        $stmt2 = $conn->prepare("UPDATE user_address SET phone=?, address=? WHERE user_id=?");
        $stmt2->bind_param("ssi", $phone, $address, $id);
        $stmt2->execute();
    } else {
        $stmt2 = $conn->prepare("INSERT INTO user_address (user_id, phone, address) VALUES (?, ?, ?)");
        $stmt2->bind_param("iss", $id, $phone, $address);
        $stmt2->execute();
    }

    $msg = "<div class='alert alert-success'>Profile Updated Successfully</div>";
}

/* FETCH DATA */
$stmt = $conn->prepare("
    SELECT u.*, ua.phone, ua.address
    FROM users u
    LEFT JOIN user_address ua ON u.user_id = ua.user_id
    WHERE u.user_id = ?
");
$stmt->bind_param("i", $id);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();
?>
<!DOCTYPE html>
<html>
<head>
<title>My Profile</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

<style>
body { background:#f4f6f9; }

.sidebar {
    min-height:100vh;
    background:#198754;
}

.sidebar a {
    color:#fff;
    display:block;
    padding:12px 15px;
    text-decoration:none;
}

.sidebar a:hover, .sidebar a.active {
    background:#157347;
}

.profile-box {
    background:#fff;
    padding:30px;
    border-radius:15px;
    box-shadow:0 5px 15px rgba(0,0,0,0.1);
}

.profile-img {
    width:130px;
    height:130px;
    border-radius:50%;
    object-fit:cover;
    border:4px solid #198754;
}
</style>
</head>

<body>
<div class="container-fluid">
<div class="row">

<!-- SIDEBAR -->
<div class="col-md-2 sidebar p-0">
<h5 class="text-center py-3 border-bottom text-white">USER PANEL</h5>

<a class="<?= ($current=='dashboard.php')?'active':'' ?>" href="dashboard.php">🏠 Dashboard</a>
<a class="<?= ($current=='book_service.php')?'active':'' ?>" href="book_service.php">🛒 Book Service</a>
<a class="<?= ($current=='my_bookings.php')?'active':'' ?>" href="my_bookings.php">📋 My Bookings</a>
<a class="<?= ($current=='profile.php')?'active':'' ?>" href="profile.php">👤 My Profile</a>
<a class="<?= ($current=='support.php')?'active':'' ?> href="support.php">💬Support</a>
<a href="../logout.php">🚪 Logout</a>
</div>

<!-- MAIN CONTENT -->
<div class="col-md-10 p-4">

<h3 class="mb-4">My Profile 👤</h3>

<?= $msg ?>

<div class="row justify-content-center">
<div class="col-md-7">

<div class="profile-box">

<div class="text-center mb-4">
<h5><?= htmlspecialchars($user['name']); ?></h5>
</div>

<form method="POST">

<div class="mb-3">
<label class="form-label">Name</label>
<input class="form-control" type="text" name="name"
value="<?= htmlspecialchars($user['name'] ?? ''); ?>" required>
</div>

<div class="mb-3">
<label class="form-label">Email</label>
<input class="form-control" type="email" name="email"
value="<?= htmlspecialchars($user['email'] ?? ''); ?>" required>
</div>

<div class="mb-3">
<label class="form-label">Phone</label>
<input class="form-control" type="text" name="phone"
value="<?= htmlspecialchars($user['phone'] ?? ''); ?>" required>
</div>

<div class="mb-3">
<label class="form-label">Address</label>
<textarea class="form-control" name="address" rows="3" required><?= htmlspecialchars($user['address'] ?? ''); ?></textarea>
</div>

<button type="submit" name="update" class="btn btn-success w-100">
Update Profile
</button>

</form>

</div>
</div>
</div>

</div>
</div>
</div>

</body>
</html>