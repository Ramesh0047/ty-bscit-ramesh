<?php
session_start();
include "../config/db.php";

if (!isset($_SESSION['user_id']) || $_SESSION['role']!='user'){
    header("Location: ../login.php");
    exit;
}

$user_id = $_SESSION['user_id'];
$message = "";

/* SUBMIT SUPPORT */
if(isset($_POST['submit'])){

$subject = mysqli_real_escape_string($conn,$_POST['subject']);
$description = mysqli_real_escape_string($conn,$_POST['description']);

/* CHECK EXISTING REQUEST (NOT RESOLVED) */
$check = mysqli_query($conn,"
SELECT request_id FROM support_requests
WHERE user_id='$user_id'
AND subject='$subject'
AND status!='Resolved'
LIMIT 1
");

if(mysqli_num_rows($check)>0){

$row=mysqli_fetch_assoc($check);
$id=$row['request_id'];

mysqli_query($conn,"
UPDATE support_requests
SET description='$description',
status='Pending',
updated_at=NOW()
WHERE request_id='$id'
");

$message="<div class='alert alert-info'>
Request updated successfully.
</div>";

}else{

mysqli_query($conn,"
INSERT INTO support_requests
(user_id,subject,description,status,created_at)
VALUES
('$user_id','$subject','$description','Pending',NOW())
");

$message="<div class='alert alert-success'>
Support request submitted successfully!
</div>";

}

}

/* FETCH MY REQUEST */
$support=mysqli_query($conn,"
SELECT request_id,subject,description,status,admin_reply,created_at
FROM support_requests
WHERE user_id='$user_id'
ORDER BY request_id DESC
");
?>
<!DOCTYPE html>
<html>
<head>
<title>Support</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<style>
body { background:#f4f6f9; }

.sidebar {
    min-height:100vh;
    background:#198754;
}

.sidebar a {
    color:#fff;
    display:block;
    padding:12px 15px;
    text-decoration:none;
}

.sidebar a:hover, .sidebar a.active {
    background:#157347;
}

.box {
    border-radius:16px;
    padding:25px;
    color:#fff;
    height:100%;
    display:flex;
    flex-direction:column;
    justify-content:center;
    transition:0.3s ease;
}

.box:hover {
    transform: translateY(-5px);
}

.stat-number {
    font-size:32px;
    font-weight:bold;
    margin-top:10px;
}
</style>
</head>

<body>
<div class="container-fluid">
<div class="row">

<div class="col-md-2 sidebar p-0">
<h5 class="text-center py-3 border-bottom text-white">USER PANEL</h5>

<a class="<?= ($current=='dashboard.php')?'active':'' ?>" href="dashboard.php">🏠 Dashboard</a>
<a class="<?= ($current=='book_service.php')?'active':'' ?>" href="book_service.php">🛒 Book Service</a>
<a class="<?= ($current=='my_bookings.php')?'active':'' ?>" href="my_bookings.php">📋 My Bookings</a>
<a class="<?= ($current=='profile.php')?'active':'' ?>" href="profile.php">👤 My Profile</a>
<a class="<?= ($current=='support.php')?'active':'' ?> href="support.php">💬Support</a>
<a href="../logout.php">🚪 Logout</a>
</div>

<div class="col-md-10 p-4">


<h3>Customer Support</h3>

<?= $message ?>

<div class="card p-4 mt-3">
<h5>Submit Support Request</h5>

<form method="POST">

<div class="mb-3">
<label>Subject</label>
<input type="text" name="subject" class="form-control" required>
</div>

<div class="mb-3">
<label>Description</label>
<textarea name="description" class="form-control" rows="4" required></textarea>
</div>

<button type="submit" name="submit" class="btn btn-primary">
Submit Request
</button>

</form>
</div>

<h5 class="mt-4">My Support Requests</h5>

<table class="table table-bordered mt-3">

<tr class="table-dark">
<th>Subject</th>
<th>Description</th>
<th>Status</th>
<th>Admin Reply</th>
<th>Date</th>
</tr>

<?php while($s=mysqli_fetch_assoc($support)){ 

$statusColor="bg-warning";

if($s['status']=="Resolved") $statusColor="bg-success";
if($s['status']=="In Progress") $statusColor="bg-primary";

?>

<tr>

<td><?= htmlspecialchars($s['subject']) ?></td>

<td><?= htmlspecialchars($s['description']) ?></td>

<td>
<span class="badge <?= $statusColor ?>">
<?= $s['status'] ?>
</span>
</td>

<td>
<?= $s['admin_reply'] ? htmlspecialchars($s['admin_reply']) : 'No reply yet' ?>
</td>

<td><?= $s['created_at'] ?></td>

</tr>

<?php } ?>

</table>

</div>

</body>
</html>