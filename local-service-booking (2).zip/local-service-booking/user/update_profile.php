<?php
session_start();
include "../config/db.php";

// AUTH
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'user') {
    header("Location: ../login.php");
    exit();
}

$userId = $_SESSION['user_id'];

// OLD DATA FETCH
$stmt = $conn->prepare("SELECT name, phone, address, profile_image FROM users WHERE user_id=?");
$stmt->bind_param("i", $userId);
$stmt->execute();
$old = $stmt->get_result()->fetch_assoc();

$oldImage = $old['profile_image'] ?? 'default.png';

// NEW VALUES (fallback to old if empty)
$name = trim($_POST['name'] ?? $old['name']);
$phone = trim($_POST['phone'] ?? $old['phone']);
$address = trim($_POST['address'] ?? $old['address']);

if ($name === '') $name = $old['name'];
if ($phone === '') $phone = $old['phone'];
if ($address === '') $address = $old['address'];

// UPLOAD FOLDER
$uploadDir = "uploads/";
if (!is_dir($uploadDir)) mkdir($uploadDir, 0777, true);

$newImage = $oldImage;

// IMAGE UPLOAD
if (!empty($_FILES['profile_image']['name'])) {

    $file = $_FILES['profile_image'];
    $allowed = ['jpg','jpeg','png'];
    $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));

    if (in_array($ext, $allowed) && $file['size'] <= 2*1024*1024) {

        $newImage = "user_" . time() . "." . $ext;
        $target = $uploadDir . $newImage;

        if (move_uploaded_file($file['tmp_name'], $target)) {
            if ($oldImage !== 'default.png' && file_exists($uploadDir . $oldImage)) {
                unlink($uploadDir . $oldImage);
            }
        }
    }
}

// UPDATE (email untouched)
$query = "UPDATE users SET name=?, phone=?, address=?, profile_image=? WHERE user_id=?";
$stmt = $conn->prepare($query);
$stmt->bind_param("ssssi", $name, $phone, $address, $newImage, $userId);
$stmt->execute();

header("Location: customer_profile.php?updated=1");
exit();
?>