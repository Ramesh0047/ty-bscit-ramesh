<?php
session_start();
include "../config/db.php";

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header("Location: ../login.php");
    exit;
}

// Fetch only normal users
$users = mysqli_query($conn, "
    SELECT user_id, name, email, area, created_at
    FROM users
    WHERE role='user'
    ORDER BY user_id DESC
");
?>

<!DOCTYPE html>
<html>
<head>
<title>View Users</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

<style>
body { background:#f4f6f9; }
.sidebar {
    min-height:100vh;
    background:#212529;
}
.sidebar a {
    color:#adb5bd;
    display:block;
    padding:12px 15px;
    text-decoration:none;
}
.sidebar a:hover, .sidebar a.active {
    background:#343a40;
    color:#fff;
}
</style>
</head>

<body>

<div class="container-fluid">
<div class="row">

    <!-- SIDEBAR -->
    <div class="col-md-2 sidebar p-0">
        <h5 class="text-white text-center py-3 border-bottom">ADMIN PANEL</h5>

        <a href="dashboard.php">📊 Dashboard</a>
        <a href="add_service.php">➕ Manage Services</a>
        <a class="active" href="view_users.php">👤 Users</a>
        <a href="view_providers.php">👷 Providers</a>
        <a href="view_bookings.php">📋 Bookings</a>
        <a href="analytics.php">📊 Analytics</a>
        <a href="../logout.php">🚪 Logout</a>
    </div>

    <!-- MAIN CONTENT -->
    <div class="col-md-10 p-4">

        <h3 class="mb-4">Registered Users</h3>

        <div class="card shadow">
            <div class="card-body">

                <table class="table table-bordered table-striped">
                    <thead class="table-dark">
                        <tr>
                            <th>ID</th>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Area</th>
                            <th>Registered On</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php
                    if (mysqli_num_rows($users) > 0) {
                        while ($u = mysqli_fetch_assoc($users)) {
                    ?>
                        <tr>
                            <td><?= $u['user_id'] ?></td>
                            <td><?= htmlspecialchars($u['name']) ?></td>
                            <td><?= htmlspecialchars($u['email']) ?></td>
                            <td><?= htmlspecialchars($u['area']) ?></td>
                            <td><?= $u['created_at'] ?></td>
                        </tr>
                    <?php
                        }
                    } else {
                    ?>
                        <tr>
                            <td colspan="5" class="text-center text-muted">
                                No users found
                            </td>
                        </tr>
                    <?php } ?>
                    </tbody>
                </table>

            </div>
        </div>

    </div>
</div>
</div>

</body>
</html>
