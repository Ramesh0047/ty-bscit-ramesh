<?php
session_start();
include "../config/db.php";

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header("Location: ../login.php");
    exit;
}

$msg = "";

// ADD SERVICE LOGIC
if (isset($_POST['add_service'])) {

    $service_name = trim($_POST['service_name']);
    $description  = trim($_POST['description']);

    if ($service_name == "") {
        $msg = "<div class='alert alert-danger'>Service name is required</div>";
    } else {

        // Duplicate check
        $check = mysqli_query($conn,
            "SELECT service_id FROM services WHERE service_name='$service_name'"
        );

        if (mysqli_num_rows($check) > 0) {
            $msg = "<div class='alert alert-warning'>Service already exists</div>";
        } else {
            mysqli_query($conn,
                "INSERT INTO services (service_name, description)
                 VALUES ('$service_name','$description')"
            );
            $msg = "<div class='alert alert-success'>Service added successfully</div>";
        }
    }
}

// FETCH SERVICES
$services = mysqli_query($conn, "SELECT * FROM services ORDER BY service_id DESC");
?>

<!DOCTYPE html>
<html>
<head>
<title>Add Service</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

<style>
body { background:#f4f6f9; }
.sidebar {
    min-height:100vh;
    background:#212529;
}
.sidebar a {
    color:#adb5bd;
    display:block;
    padding:12px 15px;
    text-decoration:none;
}
.sidebar a:hover, .sidebar a.active {
    background:#343a40;
    color:#fff;
}
</style>
</head>

<body>

<div class="container-fluid">
<div class="row">

    <!-- SIDEBAR -->
    <div class="col-md-2 sidebar p-0">
        <h5 class="text-white text-center py-3 border-bottom">ADMIN PANEL</h5>

        <a href="dashboard.php">📊 Dashboard</a>
        <a class="active" href="add_service.php">➕ Manage Services</a>
        <a href="view_users.php">👤 Users</a>
        <a href="view_providers.php">👷 Providers</a>
        <a href="view_bookings.php">📋 Bookings</a>
        <a href="analytics.php">📊 Analytics</a>
        <a href="../logout.php">🚪 Logout</a>
    </div>

    <!-- MAIN CONTENT -->
    <div class="col-md-10 p-4">

        <h3 class="mb-4">Manage Services</h3>

        <!-- ADD SERVICE FORM -->
        <div class="card shadow mb-4">
            <div class="card-body">
                <h5 class="mb-3">Add New Service</h5>

                <?= $msg ?>

                <form method="POST">
                    <div class="mb-3">
                        <label class="form-label">Service Name</label>
                        <input type="text"
                               name="service_name"
                               class="form-control"
                               placeholder="e.g. Plumber"
                               required>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Description</label>
                        <textarea name="description"
                                  class="form-control"
                                  placeholder="Optional description"></textarea>
                    </div>

                    <button type="submit"
                            name="add_service"
                            class="btn btn-primary">
                        ➕ Add Service
                    </button>
                </form>
            </div>
        </div>

        <!-- SERVICE LIST -->
        <div class="card shadow">
            <div class="card-body">
                <h5 class="mb-3">Available Services</h5>

                <table class="table table-bordered table-striped">
                    <thead class="table-dark">
                        <tr>
                            <th>ID</th>
                            <th>Service Name</th>
                            <th>Description</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php while($s = mysqli_fetch_assoc($services)) { ?>
                        <tr>
                            <td><?= $s['service_id'] ?></td>
                            <td><?= $s['service_name'] ?></td>
                            <td><?= $s['description'] ?></td>
                        </tr>
                    <?php } ?>
                    </tbody>
                </table>

            </div>
        </div>

    </div>
</div>
</div>

</body>
</html>
