<?php
session_start();
include "../config/db.php";

if (!isset($_SESSION['user_id']) || $_SESSION['role']!='admin') {
    header("Location: ../login.php");
    exit;
}

/* Monthly bookings */
$monthly = mysqli_query($conn,"
 SELECT MONTH(booking_date) m, COUNT(*) c
 FROM bookings
 GROUP BY MONTH(booking_date)
");

$months = [];
$counts = [];

while($row=mysqli_fetch_assoc($monthly)){
    $months[] = $row['m'];
    $counts[] = $row['c'];
}

/* Top Provider */
$top_provider = mysqli_fetch_assoc(mysqli_query($conn,"
 SELECT u.name, COUNT(*) total
 FROM bookings b
 JOIN users u ON b.provider_id=u.user_id
 GROUP BY b.provider_id
 ORDER BY total DESC
 LIMIT 1
"));

/* Most Booked Service */
$top_service = mysqli_fetch_assoc(mysqli_query($conn,"
 SELECT s.service_name, COUNT(*) total
 FROM bookings b
 JOIN services s ON b.service_id=s.service_id
 GROUP BY b.service_id
 ORDER BY total DESC
 LIMIT 1
"));

/* Revenue Simulation (₹500 per booking) */
$revenue = mysqli_fetch_assoc(mysqli_query($conn,"
 SELECT COUNT(*)*500 total FROM bookings WHERE status='completed'
"))['total'];

$revenue = $revenue ?: 0;
?>

<!DOCTYPE html>
<html>
<head>
<title>Admin Analytics</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body class="bg-light">

<div class="container mt-4">

<h3 class="mb-4">Admin Analytics Dashboard</h3>

<div class="row g-4 mb-4">

<div class="col-md-4">
<div class="card shadow p-3">
<h6>🏆 Top Provider</h6>
<p><?= $top_provider['name'] ?? 'N/A' ?></p>
<small><?= $top_provider['total'] ?? 0 ?> Bookings</small>
</div>
</div>

<div class="col-md-4">
<div class="card shadow p-3">
<h6>🔥 Most Booked Service</h6>
<p><?= $top_service['service_name'] ?? 'N/A' ?></p>
<small><?= $top_service['total'] ?? 0 ?> Bookings</small>
</div>
</div>

<div class="col-md-4">
<div class="card shadow p-3">
<h6>💰 Revenue (Simulated)</h6>
<h4>₹<?= $revenue ?></h4>
</div>
</div>

</div>

<div class="card shadow p-4">
<canvas id="bookingChart"></canvas>
</div>

</div>

<script>
new Chart(document.getElementById('bookingChart'), {
 type: 'bar',
 data: {
  labels: <?= json_encode($months) ?>,
  datasets: [{
    label: 'Monthly Bookings',
    data: <?= json_encode($counts) ?>
  }]
 }
});
</script>

</body>
</html>
