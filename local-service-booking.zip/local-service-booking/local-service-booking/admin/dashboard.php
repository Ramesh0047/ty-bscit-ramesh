<?php
session_start();
include "../config/db.php";

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header("Location: ../login.php");
    exit;
}

// Stats
$userCount = mysqli_fetch_assoc(mysqli_query($conn,
    "SELECT COUNT(*) c FROM users WHERE role='user'"))['c'];

$providerCount = mysqli_fetch_assoc(mysqli_query($conn,
    "SELECT COUNT(*) c FROM users WHERE role='provider'"))['c'];

$serviceCount = mysqli_fetch_assoc(mysqli_query($conn,
    "SELECT COUNT(*) c FROM services"))['c'];

$bookingCount = mysqli_fetch_assoc(mysqli_query($conn,
    "SELECT COUNT(*) c FROM bookings"))['c'];

// Booking status counts
$requested = mysqli_fetch_assoc(mysqli_query($conn,"SELECT COUNT(*) c FROM bookings WHERE status='requested'"))['c'];
$accepted  = mysqli_fetch_assoc(mysqli_query($conn,"SELECT COUNT(*) c FROM bookings WHERE status='accepted'"))['c'];
$progress  = mysqli_fetch_assoc(mysqli_query($conn,"SELECT COUNT(*) c FROM bookings WHERE status='in_progress'"))['c'];
$completed = mysqli_fetch_assoc(mysqli_query($conn,"SELECT COUNT(*) c FROM bookings WHERE status='completed'"))['c'];
$rejected  = mysqli_fetch_assoc(mysqli_query($conn,"SELECT COUNT(*) c FROM bookings WHERE status='rejected'"))['c'];
?>

<!DOCTYPE html>
<html>
<head>
    <title>Admin Dashboard</title>

    <!-- Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>

    <!-- Chart.js -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

    <style>
        body { background:#f4f6f9; }

        .sidebar {
            min-height:100vh;
            background:#212529;
        }

        .sidebar a {
            color:#adb5bd;
            text-decoration:none;
            padding:12px 15px;
            display:block;
        }

        .sidebar a:hover, .sidebar a.active {
            background:#343a40;
            color:#fff;
        }

        .stat-box {
            border-radius:12px;
            color:#fff;
            padding:20px;
        }
    </style>
</head>

<body>

<div class="container-fluid">
<div class="row">

    <!-- SIDEBAR -->
    <div class="col-md-2 sidebar p-0">
        <h5 class="text-white text-center py-3 border-bottom">ADMIN PANEL</h5>

        <a class="active" href="dashboard.php">📊 Dashboard</a>
        <a href="add_service.php">➕ Manage Services</a>
        <a href="view_users.php">👤 Users</a>
        <a href="view_providers.php">👷 Providers</a>
        <a href="view_bookings.php">📋 Bookings</a>
        <a href="analytics.php">📊 Analytics</a>
        <a href="../logout.php">🚪 Logout</a>
    </div>

    <!-- MAIN CONTENT -->
    <div class="col-md-10 p-4">

        <h3 class="mb-4">Admin Dashboard</h3>

        <!-- COLORFUL STAT BOXES -->
        <div class="row g-4 mb-4">

            <div class="col-md-3">
                <div class="stat-box bg-primary shadow">
                    <h6>Total Users</h6>
                    <h2><?= $userCount ?></h2>
                </div>
            </div>

            <div class="col-md-3">
                <div class="stat-box bg-success shadow">
                    <h6>Providers</h6>
                    <h2><?= $providerCount ?></h2>
                </div>
            </div>

            <div class="col-md-3">
                <div class="stat-box bg-warning shadow">
                    <h6>Services</h6>
                    <h2><?= $serviceCount ?></h2>
                </div>
            </div>

            <div class="col-md-3">
                <div class="stat-box bg-danger shadow">
                    <h6>Bookings</h6>
                    <h2><?= $bookingCount ?></h2>
                </div>
            </div>

        </div>

        <!-- OVERVIEW + CHART -->
        <div class="row">

            <div class="col-md-6">
                <div class="card shadow">
                    <div class="card-body">
                        <h5>System Overview</h5>
                        <ul class="mb-0">
                            <li>Secure role-based admin access</li>
                            <li>Centralized service control</li>
                            <li>Live booking monitoring</li>
                            <li>Scalable architecture</li>
                        </ul>
                    </div>
                </div>
            </div>

            <div class="col-md-6">
                <div class="card shadow">
                    <div class="card-body">
                        <h5>Booking Status Chart</h5>
                        <canvas id="bookingChart"></canvas>
                    </div>
                </div>
            </div>

        </div>

    </div>
</div>
</div>

<script>
new Chart(document.getElementById('bookingChart'), {
    type: 'doughnut',
    data: {
        labels: ['Requested','Accepted','In Progress','Completed','Rejected'],
        datasets: [{
            data: [<?= $requested ?>,<?= $accepted ?>,<?= $progress ?>,<?= $completed ?>,<?= $rejected ?>],
            backgroundColor: [
                '#0d6efd','#198754','#ffc107','#0dcaf0','#dc3545'
            ]
        }]
    }
});
</script>

</body>
</html>
