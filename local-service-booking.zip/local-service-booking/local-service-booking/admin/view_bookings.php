<?php
session_start();
include "../config/db.php";

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header("Location: ../login.php");
    exit;
}

/*
 Fetch all bookings with:
 - User name
 - Provider name
 - Service
 - Status
*/
$bookings = mysqli_query($conn, "
    SELECT 
        b.booking_id,
        b.booking_date,
        b.status,
        u.name AS user_name,
        p.name AS provider_name,
        s.service_name
    FROM bookings b
    JOIN users u ON b.user_id = u.user_id
    JOIN service_providers sp ON b.provider_id = sp.provider_id
    JOIN users p ON sp.user_id = p.user_id
    JOIN services s ON b.service_id = s.service_id
    ORDER BY b.booking_id DESC
");

if (!$bookings) {
    die("Query Error: " . mysqli_error($conn));
}
?>

<!DOCTYPE html>
<html>
<head>
<title>View Bookings</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

<style>
body { background:#f4f6f9; }
.sidebar {
    min-height:100vh;
    background:#212529;
}
.sidebar a {
    color:#adb5bd;
    display:block;
    padding:12px 15px;
    text-decoration:none;
}
.sidebar a:hover, .sidebar a.active {
    background:#343a40;
    color:#fff;
}
</style>
</head>

<body>

<div class="container-fluid">
<div class="row">

<!-- SIDEBAR -->
<div class="col-md-2 sidebar p-0">
    <h5 class="text-white text-center py-3 border-bottom">ADMIN PANEL</h5>

    <a href="dashboard.php">📊 Dashboard</a>
    <a href="add_service.php">➕ Manage Services</a>
    <a href="view_users.php">👤 Users</a>
    <a href="view_providers.php">👷 Providers</a>
    <a class="active" href="view_bookings.php">📋 Bookings</a>
    <a href="analytics.php">📊 Analytics</a>
    <a href="../logout.php">🚪 Logout</a>
</div>

<!-- MAIN CONTENT -->
<div class="col-md-10 p-4">

<h3 class="mb-4">All Bookings</h3>

<div class="card shadow">
<div class="card-body">

<table class="table table-bordered table-striped table-hover">
<thead class="table-dark">
<tr>
    <th>ID</th>
    <th>Date</th>
    <th>User</th>
    <th>Provider</th>
    <th>Service</th>
    <th>Status</th>
</tr>
</thead>

<tbody>
<?php
if (mysqli_num_rows($bookings) > 0) {
    while ($b = mysqli_fetch_assoc($bookings)) {
?>
<tr>
    <td><?= $b['booking_id'] ?></td>
    <td><?= $b['booking_date'] ?></td>
    <td><?= htmlspecialchars($b['user_name']) ?></td>
    <td><?= htmlspecialchars($b['provider_name']) ?></td>
    <td><?= htmlspecialchars($b['service_name']) ?></td>
    <td>
        <?php
        if ($b['status'] == 'requested') {
            echo "<span class='badge bg-secondary'>Requested</span>";
        } elseif ($b['status'] == 'accepted') {
            echo "<span class='badge bg-primary'>Accepted</span>";
        } elseif ($b['status'] == 'in_progress') {
            echo "<span class='badge bg-warning text-dark'>In Progress</span>";
        } elseif ($b['status'] == 'completed') {
            echo "<span class='badge bg-success'>Completed</span>";
        } elseif ($b['status'] == 'rejected') {
            echo "<span class='badge bg-danger'>Rejected</span>";
        } else {
            echo "<span class='badge bg-dark'>Unknown</span>";
        }
        ?>
    </td>
</tr>
<?php
    }
} else {
?>
<tr>
    <td colspan="6" class="text-center text-muted">
        No bookings found
    </td>
</tr>
<?php } ?>
</tbody>

</table>

</div>
</div>

</div>
</div>
</div>

</body>
</html>
