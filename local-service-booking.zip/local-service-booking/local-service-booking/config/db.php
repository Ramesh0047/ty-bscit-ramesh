<?php
$conn=mysqli_connect('localhost','root','','local_service_db');
if(!$conn){ die('DB Error'); }
?>