<?php
session_start();
include "../config/db.php";

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'provider') {
    header("Location: ../login.php");
    exit;
}

$user_id = $_SESSION['user_id'];

/* SAFELY get provider */
$pq = mysqli_query($conn,
 "SELECT provider_id FROM service_providers WHERE user_id='$user_id'");
$provider = mysqli_fetch_assoc($pq);

if (!$provider) {
    header("Location: select_service.php");
    exit;
}

$provider_id = $provider['provider_id'];

/* Update booking status */
if (isset($_GET['id'], $_GET['status'])) {
    $id = (int)$_GET['id'];
    $status = $_GET['status'];

    $allowed = ['accepted','rejected','completed'];
    if (in_array($status, $allowed)) {
        mysqli_query($conn,
            "UPDATE bookings 
             SET status='$status'
             WHERE booking_id='$id' AND provider_id='$provider_id'"
        );
    }
}

/* Fetch bookings */
$bookings = mysqli_query($conn,"
    SELECT b.booking_id,b.booking_date,b.status,
           u.name AS user_name,
           s.service_name
    FROM bookings b
    JOIN users u ON b.user_id=u.user_id
    JOIN services s ON b.service_id=s.service_id
    WHERE b.provider_id='$provider_id'
    ORDER BY b.booking_id DESC
");
?>

<!DOCTYPE html>
<html>
<head>
<title>Provider Bookings</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet"
 href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">

<style>
.sidebar { min-height:100vh; background:#0d6efd; }
.sidebar a { color:#fff; padding:12px; display:block; text-decoration:none; }
.sidebar a:hover, .sidebar a.active { background:#0b5ed7; }
</style>
</head>

<body>
<div class="container-fluid">
<div class="row">

<!-- SIDEBAR -->
<div class="col-md-2 sidebar p-0">
 <h5 class="text-center py-3">PROVIDER</h5>
 <a href="dashboard.php"><i class="bi bi-speedometer2"></i> Dashboard</a>
 <a href="select_service.php"><i class="bi bi-tools"></i> My Service</a>
 <a class="active" href="bookings.php"><i class="bi bi-list-check"></i> Bookings</a>
 <a href="../logout.php"><i class="bi bi-box-arrow-right"></i> Logout</a>
</div>

<!-- CONTENT -->
<div class="col-md-10 p-4">
<h3 class="mb-4">My Bookings</h3>

<table class="table table-bordered table-hover">
<thead class="table-dark">
<tr>
 <th>Date</th>
 <th>User</th>
 <th>Service</th>
 <th>Status</th>
 <th>Action</th>
</tr>
</thead>
<tbody>

<?php
if (mysqli_num_rows($bookings) > 0) {
while($b = mysqli_fetch_assoc($bookings)){
?>
<tr>
 <td><?= $b['booking_date'] ?></td>
 <td><?= htmlspecialchars($b['user_name']) ?></td>
 <td><?= htmlspecialchars($b['service_name']) ?></td>
 <td>
<?php
 if ($b['status']=='requested')
   echo "<span class='badge bg-secondary'>Requested</span>";
 elseif ($b['status']=='accepted')
   echo "<span class='badge bg-primary'>Accepted</span>";
 elseif ($b['status']=='completed')
   echo "<span class='badge bg-success'>Completed</span>";
 elseif ($b['status']=='rejected')
   echo "<span class='badge bg-danger'>Rejected</span>";
?>
 </td>

 <td>
<?php if ($b['status']=='requested'){ ?>
 <a href="?id=<?= $b['booking_id'] ?>&status=accepted"
    class="btn btn-success btn-sm">Accept</a>

 <a href="?id=<?= $b['booking_id'] ?>&status=rejected"
    class="btn btn-danger btn-sm">Reject</a>

<?php } elseif ($b['status']=='accepted'){ ?>
 <a href="?id=<?= $b['booking_id'] ?>&status=completed"
    class="btn btn-primary btn-sm">Complete</a>
<?php } else { echo "-"; } ?>
 </td>
</tr>
<?php } } else { ?>
<tr>
 <td colspan="5" class="text-center text-muted">
   No bookings found
 </td>
</tr>
<?php } ?>

</tbody>
</table>

</div>
</div>
</div>
</body>
</html>
