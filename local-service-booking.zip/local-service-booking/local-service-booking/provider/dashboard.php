<?php
session_start();
include "../config/db.php";

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'provider') {
    header("Location: ../login.php");
    exit;
}

$user_id = $_SESSION['user_id'];

/* Get provider safely */
$pq = mysqli_query($conn,
 "SELECT provider_id, availability 
  FROM service_providers 
  WHERE user_id='$user_id'");
$provider = mysqli_fetch_assoc($pq);

if (!$provider) {
    header("Location: select_service.php");
    exit;
}

$provider_id = $provider['provider_id'];
$availability = $provider['availability'] ?? 'no';
$status = ($availability === 'yes') ? 'Active' : 'Inactive';

/* Dashboard stats */
$total = mysqli_fetch_assoc(mysqli_query($conn,
 "SELECT COUNT(*) c FROM bookings WHERE provider_id='$provider_id'"))['c'];

$pending = mysqli_fetch_assoc(mysqli_query($conn,
 "SELECT COUNT(*) c FROM bookings 
  WHERE provider_id='$provider_id' AND status='requested'"))['c'];

$completed = mysqli_fetch_assoc(mysqli_query($conn,
 "SELECT COUNT(*) c FROM bookings 
  WHERE provider_id='$provider_id' AND status='completed'"))['c'];
?>

<!DOCTYPE html>
<html>
<head>
<title>Provider Dashboard</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet"
 href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>

<style>
body { background:#f4f6f9; }
.sidebar { min-height:100vh; background:#0d6efd; }
.sidebar a { color:#fff; display:block; padding:12px; text-decoration:none; }
.sidebar a:hover, .sidebar a.active { background:#0b5ed7; }
.stat { border-radius:12px; color:#fff; padding:20px; }
body.dark { background:#121212; color:#fff; }
body.dark .card { background:#1e1e1e; }
</style>

<script>
function toggleTheme(){
 document.body.classList.toggle('dark');
 localStorage.setItem(
   'theme',
   document.body.classList.contains('dark') ? 'dark' : 'light'
 );
}
window.onload = () => {
 if(localStorage.getItem('theme') === 'dark'){
  document.body.classList.add('dark');
 }
}
</script>
</head>

<body>
<div class="container-fluid">
<div class="row">

<!-- SIDEBAR -->
<div class="col-md-2 sidebar p-0">
 <h5 class="text-center py-3">PROVIDER</h5>
 <a class="active" href="dashboard.php"><i class="bi bi-speedometer2"></i> Dashboard</a>
 <a href="select_service.php"><i class="bi bi-tools"></i> My Service</a>
 <a href="bookings.php"><i class="bi bi-list-check"></i> Bookings</a>
 <a href="../logout.php"><i class="bi bi-box-arrow-right"></i> Logout</a>
</div>

<!-- CONTENT -->
<div class="col-md-10 p-4">

 <div class="d-flex justify-content-between mb-4">
   <h3>Provider Dashboard</h3>
   <button onclick="toggleTheme()" class="btn btn-outline-secondary">
     🌙 / ☀️
   </button>
 </div>

 <!-- STATS -->
 <div class="row g-4 mb-4">

   <div class="col-md-3">
     <div class="stat bg-primary shadow">
       <h6>Total Jobs</h6>
       <h2><?= $total ?></h2>
     </div>
   </div>

   <div class="col-md-3">
     <div class="stat bg-warning text-dark shadow">
       <h6>Pending</h6>
       <h2><?= $pending ?></h2>
     </div>
   </div>

   <div class="col-md-3">
     <div class="stat bg-success shadow">
       <h6>Completed</h6>
       <h2><?= $completed ?></h2>
     </div>
   </div>

   <div class="col-md-3">
     <div class="stat <?= ($status=='Active')?'bg-info':'bg-secondary' ?> shadow">
       <h6>Status</h6>
       <h2><?= $status ?></h2>
     </div>
   </div>

 </div>

 <!-- QUICK ACTION -->
 <div class="card shadow col-md-4">
  <div class="card-body text-center">
    <h5>My Bookings</h5>
    <a href="bookings.php" class="btn btn-primary mt-2">View</a>
  </div>
 </div>

</div>
</div>
</div>
</body>
</html>
