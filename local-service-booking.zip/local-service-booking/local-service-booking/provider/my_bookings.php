<?php
session_start();
include "../config/db.php";

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'user') {
    header("Location: ../login.php");
    exit;
}

$user_id = $_SESSION['user_id'];

$bookings = mysqli_query($conn,"
    SELECT b.booking_date,b.status,s.service_name
    FROM bookings b
    JOIN services s ON b.service_id=s.service_id
    WHERE b.user_id='$user_id'
    ORDER BY b.booking_id DESC
");
?>

<!DOCTYPE html>
<html>
<head>
<title>My Bookings</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body>
<div class="container-fluid">
<div class="row">

<div class="col-md-2 bg-success text-white min-vh-100 p-0">
 <h5 class="text-center py-3">USER</h5>
 <a class="d-block text-white p-2" href="dashboard.php">Dashboard</a>
 <a class="d-block text-white p-2 bg-dark" href="my_bookings.php">My Bookings</a>
 <a class="d-block text-white p-2" href="../logout.php">Logout</a>
</div>

<div class="col-md-10 p-4">
<h3>My Bookings</h3>

<table class="table table-bordered">
<thead class="table-dark">
<tr>
 <th>Date</th>
 <th>Service</th>
 <th>Status</th>
</tr>
</thead>
<tbody>

<?php while($b=mysqli_fetch_assoc($bookings)){ ?>
<tr>
 <td><?= $b['booking_date'] ?></td>
 <td><?= htmlspecialchars($b['service_name']) ?></td>
 <td><?= $b['status'] ?></td>
</tr>
<?php } ?>

</tbody>
</table>

</div>
</div>
</div>
</body>
</html>
