<?php
session_start();
include "../config/db.php";

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'provider') {
    header("Location: ../login.php");
    exit;
}

$user_id = $_SESSION['user_id'];
$msg = "";

/* Fetch all services */
$services = mysqli_query($conn, "SELECT * FROM services ORDER BY service_name");

/* Check existing provider record */
$existing = mysqli_query($conn,
    "SELECT * FROM service_providers WHERE user_id='$user_id'"
);
$current = mysqli_fetch_assoc($existing);

/* Save / Update service */
if (isset($_POST['save'])) {

    $service_id   = $_POST['service_id'];
    $availability = $_POST['availability'];

    if ($current) {
        // Update
        mysqli_query($conn,
            "UPDATE service_providers
             SET service_id='$service_id', availability='$availability'
             WHERE user_id='$user_id'"
        );
    } else {
        // Insert
        mysqli_query($conn,
            "INSERT INTO service_providers (user_id, service_id, availability)
             VALUES ('$user_id','$service_id','$availability')"
        );
    }

    // After save → go to dashboard
    header("Location: dashboard.php");
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Select Service</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet"
 href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">

<style>
body { background:#f4f6f9; }
.sidebar {
    min-height:100vh;
    background:#0d6efd;
}
.sidebar a {
    color:#fff;
    padding:12px;
    display:block;
    text-decoration:none;
}
.sidebar a:hover, .sidebar a.active {
    background:#0b5ed7;
}
</style>
</head>

<body>
<div class="container-fluid">
<div class="row">

<!-- SIDEBAR -->
<div class="col-md-2 sidebar p-0">
 <h5 class="text-center py-3">PROVIDER</h5>

 <a href="dashboard.php">
   <i class="bi bi-speedometer2"></i> Dashboard
 </a>

 <a class="active" href="select_service.php">
   <i class="bi bi-tools"></i> My Service
 </a>

 <a href="bookings.php">
   <i class="bi bi-list-check"></i> Bookings
 </a>

 <a href="../logout.php">
   <i class="bi bi-box-arrow-right"></i> Logout
 </a>
</div>

<!-- MAIN CONTENT -->
<div class="col-md-10 p-4">

<h3 class="mb-4">Select / Update Service</h3>

<div class="card shadow col-md-6">
<div class="card-body">

<form method="POST">

    <div class="mb-3">
        <label class="form-label">Service</label>
        <select name="service_id" class="form-select" required>
            <option value="">-- Select Service --</option>
            <?php
            while ($s = mysqli_fetch_assoc($services)) {
                $selected = ($current && $current['service_id'] == $s['service_id'])
                            ? "selected" : "";
                echo "<option value='{$s['service_id']}' $selected>
                        {$s['service_name']}
                      </option>";
            }
            ?>
        </select>
    </div>

    <div class="mb-3">
        <label class="form-label">Availability</label>
        <select name="availability" class="form-select">
            <option value="yes" <?= ($current && $current['availability']=='yes')?'selected':'' ?>>
                Available
            </option>
            <option value="no" <?= ($current && $current['availability']=='no')?'selected':'' ?>>
                Not Available
            </option>
        </select>
    </div>

    <button type="submit" name="save" class="btn btn-primary">
        💾 Save
    </button>

</form>

</div>
</div>

</div>
</div>
</div>
</body>
</html>
