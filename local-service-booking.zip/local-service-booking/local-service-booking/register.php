<?php
include "config/db.php";
$msg = "";

if (isset($_POST['register'])) {

    $name  = trim($_POST['name']);
    $email = trim($_POST['email']);
    $pass  = $_POST['password'];
    $role  = $_POST['role'];
    $area  = trim($_POST['area']);

    // basic validation
    if ($name=="" || $email=="" || $pass=="" || $role=="") {
        $msg = "All fields are required";
    } else {

        // check email exists
        $check = mysqli_query($conn,
            "SELECT user_id FROM users WHERE email='$email'"
        );

        if (mysqli_num_rows($check) > 0) {
            $msg = "Email already registered";
        } else {

            $hash = password_hash($pass, PASSWORD_DEFAULT);

            mysqli_query($conn,"
                INSERT INTO users (name,email,password,role,area)
                VALUES ('$name','$email','$hash','$role','$area')
            ");

            $msg = "Registration successful. Please login.";
        }
    }
}
?>
<!DOCTYPE html>
<html>
<head>
<title>Register</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body class="bg-light">

<div class="container mt-5 col-md-4">
<h3 class="mb-3 text-center">Register</h3>

<?php if($msg!=""){ ?>
<div class="alert alert-info"><?= $msg ?></div>
<?php } ?>

<form method="POST">

<input class="form-control mb-2" name="name" placeholder="Full Name" required>

<input class="form-control mb-2" type="email" name="email"
       placeholder="Email" required>

<input class="form-control mb-2" type="password" name="password"
       placeholder="Password" required>

<select class="form-select mb-2" name="role" required>
    <option value="">Select Role</option>
    <option value="user">User</option>
    <option value="provider">Provider</option>
</select>

<input class="form-control mb-3" name="area"
       placeholder="Area / City">

<button class="btn btn-primary w-100" name="register">
Register
</button>

<div class="text-center mt-3">
<a href="login.php">Already have account? Login</a>
</div>

</form>
</div>
</body>
</html>
