<?php
session_start();
include "../config/db.php";

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'user') {
    header("Location: ../login.php");
    exit;
}

$user_id = $_SESSION['user_id'];
$msg = "";

/* Fetch all services */
$services = mysqli_query($conn, "SELECT * FROM services ORDER BY service_name");

/* Book service */
if (isset($_POST['book'])) {

    $service_id = $_POST['service_id'];

    // Find available provider for this service
    $pq = mysqli_query($conn, "
        SELECT provider_id 
        FROM service_providers 
        WHERE service_id='$service_id' 
          AND availability='yes'
        LIMIT 1
    ");

    if ($pq && mysqli_num_rows($pq) > 0) {

        $provider = mysqli_fetch_assoc($pq);
        $provider_id = $provider['provider_id'];

        mysqli_query($conn, "
            INSERT INTO bookings (user_id, provider_id, service_id, booking_date, status)
            VALUES ('$user_id', '$provider_id', '$service_id', CURDATE(), 'requested')
        ");

        $msg = "<div class='alert alert-success'>Service booked successfully</div>";

    } else {
        $msg = "<div class='alert alert-danger'>No provider available for this service</div>";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Book Service</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

<style>
body { background:#f4f6f9; }
.sidebar {
    min-height:100vh;
    background:#198754;
}
.sidebar a {
    color:#fff;
    padding:12px 15px;
    display:block;
    text-decoration:none;
}
.sidebar a:hover, .sidebar a.active {
    background:#157347;
}
</style>
</head>

<body>

<div class="container-fluid">
<div class="row">

<!-- SIDEBAR -->
<div class="col-md-2 sidebar p-0">
    <h5 class="text-center py-3 border-bottom">USER PANEL</h5>

    <a href="dashboard.php">🏠 Dashboard</a>
    <a class="active" href="book_service.php">🛒 Book Service</a>
    <a href="my_bookings.php">📋 My Bookings</a>
    <a href="../logout.php">🚪 Logout</a>
</div>

<!-- MAIN CONTENT -->
<div class="col-md-10 p-4">

    <h3 class="mb-4">Book a Service</h3>

    <?= $msg ?>

    <div class="card shadow col-md-5">
        <div class="card-body">

            <form method="POST">

                <div class="mb-3">
                    <label class="form-label">Select Service</label>
                    <select name="service_id" class="form-select" required>
                        <option value="">-- Select Service --</option>
                        <?php
                        while ($s = mysqli_fetch_assoc($services)) {
                            echo "<option value='{$s['service_id']}'>
                                    {$s['service_name']}
                                  </option>";
                        }
                        ?>
                    </select>
                </div>

                <button type="submit" name="book" class="btn btn-primary">
                    📌 Book Now
                </button>

            </form>

        </div>
    </div>

</div>
</div>
</div>

</body>
</html>
