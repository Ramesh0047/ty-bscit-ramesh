<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'user') {
    header("Location: ../login.php");
    exit;
}
include "../config/db.php";

$uid = $_SESSION['user_id'];

$total = mysqli_fetch_assoc(mysqli_query($conn,
 "SELECT COUNT(*) c FROM bookings WHERE user_id='$uid'"))['c'];

$completed = mysqli_fetch_assoc(mysqli_query($conn,
 "SELECT COUNT(*) c FROM bookings
  WHERE user_id='$uid' AND status='completed'"))['c'];

$feedbacks = mysqli_fetch_assoc(mysqli_query($conn,
 "SELECT COUNT(*) c FROM feedback f
  JOIN bookings b ON f.booking_id=b.booking_id
  WHERE b.user_id='$uid'"))['c'];
?>

<!DOCTYPE html>
<html>
<head>
<title>User Dashboard</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

<style>
body { background:#f4f6f9; }
.sidebar {
    min-height:100vh;
    background:#198754;
}
.sidebar a {
    color:#fff;
    display:block;
    padding:12px 15px;
    text-decoration:none;
}
.sidebar a:hover, .sidebar a.active {
    background:#157347;
}
.box {
    border-radius:14px;
    color:#fff;
    padding:22px;
    height:100%;
}
</style>
</head>

<body>
<div class="container-fluid">
<div class="row">

<!-- SIDEBAR -->
<div class="col-md-2 sidebar p-0">
    <h5 class="text-center py-3 border-bottom">USER PANEL</h5>
    <a class="active" href="dashboard.php">🏠 Dashboard</a>
    <a href="book_service.php">🛒 Book Service</a>
    <a href="my_bookings.php">📋 My Bookings</a>
    <a href="../logout.php">🚪 Logout</a>
</div>

<!-- MAIN CONTENT -->
<div class="col-md-10 p-4">

<h3 class="mb-4">Welcome User</h3>

<!-- ACTION CARDS -->
<div class="row g-4 mb-4">

    <div class="col-md-4">
        <div class="box bg-primary shadow">
            <h6>Book a Service</h6>
            <p class="mb-0">Request local services easily</p>
        </div>
    </div>

    <div class="col-md-4">
        <div class="box bg-warning text-dark shadow">
            <h6>Track Bookings</h6>
            <p class="mb-0">Check service status</p>
        </div>
    </div>

</div>

<!-- STATS -->
<div class="row g-4 mb-4">

    <div class="col-md-3">
        <div class="box bg-primary shadow">
            <h6>Total Bookings</h6>
            <h2><?= $total ?></h2>
        </div>
    </div>

    <div class="col-md-3">
        <div class="box bg-success shadow">
            <h6>Completed</h6>
            <h2><?= $completed ?></h2>
        </div>
    </div>

    <div class="col-md-3">
        <div class="box bg-warning text-dark shadow">
            <h6>Feedback Given</h6>
            <h2><?= $feedbacks ?></h2>
        </div>
    </div>

</div>

<!-- INFO -->
<div class="row g-4">

    <div class="col-md-4">
        <div class="box bg-success shadow">
            <h6>Fast Support</h6>
            <p class="mb-0">Verified providers</p>
        </div>
    </div>

</div>

</div>
</div>
</div>
</body>
</html>
