<?php
session_start();
include "../config/db.php";

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'user') {
    header("Location: ../login.php");
    exit;
}

$user_id = $_SESSION['user_id'];
$booking_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$msg = "";

/* Verify booking belongs to user & completed */
$chk = mysqli_query($conn, "
    SELECT b.booking_id
    FROM bookings b
    WHERE b.booking_id='$booking_id'
      AND b.user_id='$user_id'
      AND b.status='completed'
");

if (mysqli_num_rows($chk) == 0) {
    die("Invalid booking or service not completed.");
}

/* Prevent duplicate feedback */
$exist = mysqli_query($conn,
    "SELECT feedback_id FROM feedback WHERE booking_id='$booking_id'"
);
if (mysqli_num_rows($exist) > 0) {
    die("Feedback already submitted.");
}

/* Submit feedback */
if (isset($_POST['submit'])) {
    $rating  = (int)$_POST['rating'];
    $comment = trim($_POST['comment']);

    if ($rating < 1 || $rating > 5) {
        $msg = "<div class='alert alert-danger'>Invalid rating</div>";
    } else {
        mysqli_query($conn,"
            INSERT INTO feedback (booking_id, rating, comment)
            VALUES ('$booking_id','$rating','$comment')
        ");
        $msg = "<div class='alert alert-success'>Thank you for your feedback</div>";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Feedback</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body class="bg-light">
<div class="container mt-5 col-md-5">

<h4 class="mb-3">Give Feedback</h4>

<?= $msg ?>

<form method="POST">

<div class="mb-3">
    <label class="form-label">Rating</label>
    <select name="rating" class="form-select" required>
        <option value="">Select</option>
        <option>1</option><option>2</option><option>3</option>
        <option>4</option><option>5</option>
    </select>
</div>

<div class="mb-3">
    <label class="form-label">Comment</label>
    <textarea name="comment" class="form-control"></textarea>
</div>

<button class="btn btn-primary" name="submit">Submit</button>
<a href="my_bookings.php" class="btn btn-secondary">Back</a>

</form>
</div>
</body>
</html>
