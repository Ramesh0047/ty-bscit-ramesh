<?php
session_start();
include "../config/db.php";

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'user') {
    header("Location: ../login.php");
    exit;
}

$user_id = $_SESSION['user_id'];

/* Fetch user bookings */
$bookings = mysqli_query($conn, "
    SELECT 
        b.booking_id,
        b.booking_date,
        b.status,
        s.service_name,
        u.name AS provider_name
    FROM bookings b
    JOIN services s ON b.service_id = s.service_id
    JOIN service_providers sp ON b.provider_id = sp.provider_id
    JOIN users u ON sp.user_id = u.user_id
    WHERE b.user_id = '$user_id'
    ORDER BY b.booking_id DESC
");

if (!$bookings) {
    die("Query Error: " . mysqli_error($conn));
}
?>

<!DOCTYPE html>
<html>
<head>
<title>My Bookings</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

<style>
body { background:#f4f6f9; }
.sidebar {
    min-height:100vh;
    background:#198754;
}
.sidebar a {
    color:#fff;
    padding:12px 15px;
    display:block;
    text-decoration:none;
}
.sidebar a:hover, .sidebar a.active {
    background:#157347;
}
</style>
</head>

<body>

<div class="container-fluid">
<div class="row">

<!-- SIDEBAR -->
<div class="col-md-2 sidebar p-0">
    <h5 class="text-center py-3 border-bottom">USER PANEL</h5>

    <a href="dashboard.php">🏠 Dashboard</a>
    <a href="book_service.php">🛒 Book Service</a>
    <a class="active" href="my_bookings.php">📋 My Bookings</a>
    <a href="../logout.php">🚪 Logout</a>
</div>

<!-- MAIN CONTENT -->
<div class="col-md-10 p-4">

<h3 class="mb-4">My Bookings</h3>

<div class="card shadow">
<div class="card-body">

<table class="table table-bordered table-striped table-hover">
<thead class="table-dark">
<tr>
    <th>ID</th>
    <th>Date</th>
    <th>Service</th>
    <th>Provider</th>
    <th>Status</th>
</tr>
</thead>

<tbody>
<?php
if (mysqli_num_rows($bookings) > 0) {
    while ($b = mysqli_fetch_assoc($bookings)) {
?>
<tr>
    <td><?= $b['booking_id'] ?></td>
    <td><?= $b['booking_date'] ?></td>
    <td><?= htmlspecialchars($b['service_name']) ?></td>
    <td><?= htmlspecialchars($b['provider_name']) ?></td>
    <td>
        <?php
        if ($b['status'] == 'requested') {
            echo "<span class='badge bg-secondary'>Requested</span>";
        } elseif ($b['status'] == 'accepted') {
            echo "<span class='badge bg-primary'>Accepted</span>";
        } elseif ($b['status'] == 'in_progress') {
            echo "<span class='badge bg-warning text-dark'>In Progress</span>";
        } elseif ($b['status'] == 'completed') {
            echo "<span class='badge bg-success'>Completed</span>";
        } elseif ($b['status'] == 'rejected') {
            echo "<span class='badge bg-danger'>Rejected</span>";
        } else {
            echo "<span class='badge bg-dark'>Unknown</span>";
        }
        ?>
    </td>
    <td>
        <?php if($b['status']=='completed'){ ?>
        <a href="feedback.php?id=<?= $b['booking_id'] ?>"
            class="btn btn-success btn-sm">
            Give Feedback
        </a>
        <?php } else { echo "-"; } ?>
    </td>
</tr>
<?php
    }
} else {
?>
<tr>
    <td colspan="5" class="text-center text-muted">
        You have no bookings yet
    </td>
</tr>
<?php } ?>
</tbody>

</table>

</div>
</div>

</div>
</div>
</div>

</body>
</html>
