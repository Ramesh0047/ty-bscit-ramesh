<?php
session_start();
include "../config/db.php";

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

if ($_SESSION['role'] != 'user') {
    header("Location: ../unauthorized.php");
    exit();
}


$id = $_SESSION['user_id'];

$query = "SELECT * FROM users WHERE user_id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $id);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();


$current = basename($_SERVER['PHP_SELF']);
?>

<!DOCTYPE html>
<html>
<head>
<title>Customer Profile</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

<style>
body { background: #f4f6f9; }
.sidebar { height: 100vh; background: #fff; border-right: 1px solid #ddd; }
.sidebar a { display: block; padding: 12px 15px; color: #333; text-decoration: none; border-bottom: 1px solid #eee; }
.sidebar a:hover { background: #f1f1f1; }
.sidebar .active { background: #0d6efd; color: #fff; font-weight: bold; }
.profile-box { background: #fff; padding: 25px; border-radius: 10px; box-shadow: 0 0 10px #ddd; }
.profile-img { width: 120px; height: 120px; border-radius: 50%; object-fit: cover; }
</style>
</head>

<body>
<div class="container-fluid">
<div class="row">

<div class="col-md-2 sidebar p-0">
<h5 class="text-center py-3 border-bottom">USER PANEL</h5>
<a class="<?= ($current=='dashboard.php')?'active':'' ?>" href="dashboard.php">🏠 Dashboard</a>
<a class="<?= ($current=='book_service.php')?'active':'' ?>" href="book_service.php">🛒 Book Service</a>
<a class="<?= ($current=='my_bookings.php')?'active':'' ?>" href="my_bookings.php">📋 My Bookings</a>
<a class="<?= ($current=='customer_profile.php')?'active':'' ?>" href="customer_profile.php">👤 My Profile</a>
<a href="../logout.php">🚪 Logout</a>
</div>

<div class="col-md-10 p-4">
<div class="profile-box">
<h3 class="mb-4">My Profile</h3>

<div class="text-center mb-3">
<?php
$image = $user['profile_image'] ?? '';
if (!$image || !file_exists("uploads/" . $image)) {
    $image = "default.png";
}
?>
<img class="profile-img" src="uploads/<?php echo $image; ?>">
</div>

<form action="update_customer_profile.php" method="POST" enctype="multipart/form-data">
<input type="hidden" name="id" value="<?= $user['user_id']; ?>">

<label>Name</label>
<input class="form-control mb-3" type="text" name="name"
value="<?= htmlspecialchars($user['name']); ?>" required>

<label>Email</label>
<input class="form-control mb-3" type="email" name="email"
value="<?= htmlspecialchars($user['email']); ?>" required>

<label>Phone</label>
<input class="form-control mb-3" type="text" name="phone"
value="<?= htmlspecialchars($user['phone']); ?>" required>

<label>Address</label>
<textarea class="form-control mb-3" name="address" required><?= htmlspecialchars($user['address']); ?></textarea>

<label>Profile Image</label>
<input class="form-control mb-3" type="file" name="profile_image">

<button class="btn btn-primary">Update Profile</button>
</form>
</div>
</div>

</div>
</div>
</body>
</html>